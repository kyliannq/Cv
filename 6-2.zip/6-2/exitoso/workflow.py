"""
workflow.py - Lógica de negocio y state machine del flujo RSIRAT
Responsabilidades:
  1. Definir Outcome (enums) y ContextoExpediente (dataclass)
  2. Orquestar el flujo por dependencia (state machine con has_active_expediente)
  3. Procesar cada expediente: categorizar tipo (IEI/DSE) y ejecutar flujo
  4. Manejar retorno a "Accesos → Cambio de Expediente" después del primer expediente válido
  5. Retornar list de outcomes con razones
"""

from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Dict, Callable, Optional
import logging
import pandas as pd
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from app_driver import AppDriver


# ============================================================================
# ENUMS Y DATACLASSES
# ============================================================================
class Outcome(Enum):
    """Estados posibles al terminar un expediente."""
    OK_RC = auto()                          # Éxito: RC grabada
    SKIP_EXP_INVALIDO = auto()              # Expediente inválido en RSIRAT
    SKIP_INTERVENTOR_INVALIDO = auto()      # Código de interventor inválido (IEI)
    SKIP_MONTO_MAYOR = auto()               # Monto excede saldo (DSE)
    FAIL_LOGIN_PASSWORD = auto()             # Contraseña incorrecta (crítico)
    FAIL_UI = auto()                        # Error UI inesperado
    SKIP_DATA_INCOMPLETE = auto()            # Datos incompletos en Excel


@dataclass
class ContextoExpediente:
    """Contexto de un expediente siendo procesado."""
    expediente: str
    row_idx: int
    dependencia: str
    tipo_medida: str  # "IEI" o "DSE"
    interventor: Optional[str] = None
    ejecutor: Optional[str] = None
    plazo: Optional[int] = None
    monto: Optional[float] = None


@dataclass
class ProcessOutcome:
    """Resultado del procesamiento de un expediente."""
    expediente: str
    row_idx: int
    dependencia: str
    outcome: Outcome
    rc_number: Optional[str] = None
    reason: str = ""
    error_detail: str = ""


# ============================================================================
# VALIDACIONES EXCEL
# ============================================================================
def validate_expediente_row(row: pd.Series, row_idx: int) -> tuple[bool, str]:
    """
    Valida que una fila del Excel tenga los datos necesarios.
    
    Retorna: (is_valid, error_msg)
    """
    dependencia = str(row.get("DEPENDENCIA", "")).strip()
    tipo = str(row.get("TIPO DE MEDIDA", "")).strip().upper()
    interventor = str(row.get("INTERVENTOR", "")).strip()
    plazo = str(row.get("PLAZO", "")).strip()
    monto = str(row.get("MONTO", "")).strip()
    
    # Validar DEPENDENCIA
    if not dependencia or dependencia == "nan":
        return False, "Falta DEPENDENCIA"
    
    # Validar TIPO DE MEDIDA
    if not tipo or tipo == "NAN":
        return False, "Falta TIPO DE MEDIDA"
    
    if tipo not in ["IEI", "DSE"]:
        return False, f"TIPO DE MEDIDA debe ser IEI o DSE, encontrado: {tipo}"
    
    # Validar según tipo
    if "IEI" in tipo:
        if not interventor or interventor == "nan":
            return False, "IEI requiere INTERVENTOR"
        if not plazo or plazo == "nan":
            return False, "IEI requiere PLAZO"
    
    elif "DSE" in tipo:
        if not monto or monto == "nan":
            return False, "DSE requiere MONTO"
    
    return True, ""


# ============================================================================
# ESTADO MACHINE PRINCIPAL
# ============================================================================
def process_dependency(
    dependencia: str,
    indices: List[int],
    df: pd.DataFrame,
    driver: "AppDriver",
    update_result_fn: Callable,
    is_first: bool,
    is_last: bool,
    logger: logging.Logger,
    password: str,
    update_ejecutor_fn: Optional[Callable] = None
) -> List[ProcessOutcome]:
    """
    Procesa TODOS los expedientes de una dependencia en una sesión.
    
    State machine:
      1. Si is_first: abrir app + login
      2. Navegar a modulo base
      3. Para cada expediente:
         - Si es el primero válido: entrar sin Accesos, luego has_active=True
         - Si es siguiente: ir a Accesos → Cambio expediente
         - Procesar (IEI o DSE)
      4. Si is_last: cerrar app
    
    Retorna: lista de ProcessOutcome
    """
    outcomes = []
    has_active_expediente = False  # Controla si podemos usar "Accesos"
    
    logger.info(f"Iniciando procesamiento de {len(indices)} expediente(s)...")
    
    # -------- FASE 1: Abrir app y login (solo si es primera dependencia) --------
    if is_first:
        logger.info("[INIT] Abriendo aplicación...")
        if not driver.open_app():
            logger.error("  ✗ No se pudo abrir la aplicación")
            # Registrar fallo en todos los expedientes
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo abrir aplicación"
                ))
            return outcomes
        
        logger.info("[LOGIN] Autenticando...")
        login_outcome = driver.login(dependencia, password)
        if login_outcome != Outcome.OK_RC:
            logger.error(f"  ✗ Login falló: {login_outcome.name}")
            # Registrar fallo en todos los expedientes
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=login_outcome,
                    reason="Fallo en login"
                ))

            # Actualizar SOLO la PRIMERA fila con el mensaje específico de contraseña
            try:
                if login_outcome == Outcome.FAIL_LOGIN_PASSWORD and len(indices) > 0:
                    first_row = indices[0]
                    update_result_fn(first_row, "CONTRASEÑA INCORRECTA")
            except Exception as e:
                logger.warning(f"No se pudo actualizar Excel (primer fila) por fallo de login: {e}")

            return outcomes
        
        logger.info("   Login exitoso")
        
        # Navegar al módulo (Cobranza Coactiva)
        logger.info("[NAV] Navegando a módulo base...")
        if not driver.navigate_to_module():
            logger.error("  ✗ No se pudo navegar al módulo")
            for row_idx in indices:
                outcomes.append(ProcessOutcome(
                    expediente=df.iloc[row_idx]["EXPEDIENTE"],
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo navegar al módulo"
                ))
            return outcomes
        
        logger.info("   Módulo listo")
    
    # -------- FASE 2: Procesar cada expediente --------
    for pos, row_idx in enumerate(indices, 1):
        logger.info(f"\n[EXP {pos}/{len(indices)}] Procesando fila {row_idx + 1}...")
        
        row = df.iloc[row_idx]
        expediente = str(row["EXPEDIENTE"]).strip()
        
        # Validar datos en Excel
        is_valid, error_msg = validate_expediente_row(row, row_idx)
        if not is_valid:
            logger.warning(f"   Datos incompletos: {error_msg}")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=Outcome.SKIP_DATA_INCOMPLETE,
                reason=error_msg
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, error_msg)
            continue
        
        # Crear contexto (usar conversiones seguras para PLAZO y MONTO)
        # Interventor
        interventor_val = None
        if "INTERVENTOR" in row.index:
            iv_raw = row.get("INTERVENTOR", "")
            if pd.notna(iv_raw):
                s_iv = str(iv_raw).strip()
                if s_iv != "":
                    interventor_val = s_iv

        # Plazo (int seguro)
        plazo_val = None
        if "PLAZO" in row.index:
            raw_plazo = row["PLAZO"]
            if pd.notna(raw_plazo):
                s_plazo = str(raw_plazo).strip()
                if s_plazo != "":
                    try:
                        # Manejar valores como '1.0' o '1'
                        plazo_val = int(float(s_plazo))
                    except Exception:
                        plazo_val = None

        # Monto (float seguro)
        monto_val = None
        if "MONTO" in row.index:
            raw_monto = row["MONTO"]
            if pd.notna(raw_monto):
                s_monto = str(raw_monto).strip()
                if s_monto != "":
                    try:
                        monto_val = float(s_monto)
                    except Exception:
                        monto_val = None

        # Ejecutora/ejecutor esperado (desde Excel, columna 'EJECUTOR' opcional)
        ejecutor_val = None
        if "EJECUTOR" in row.index:
            raw_ejec = row.get("EJECUTOR", "")
            if pd.notna(raw_ejec):
                s_ejec = str(raw_ejec).strip()
                if s_ejec != "":
                    ejecutor_val = s_ejec

        ctx = ContextoExpediente(
            expediente=expediente,
            row_idx=row_idx,
            dependencia=dependencia,
            tipo_medida=str(row["TIPO DE MEDIDA"]).strip().upper(),
            interventor=interventor_val,
            ejecutor=ejecutor_val,
            plazo=plazo_val,
            monto=monto_val
        )
        
        # -------- Ingresar expediente --------
        if has_active_expediente:
            logger.info(f"  Accediendo a 'Cambio de Expediente'...")
            if not driver.go_to_accesos_change_expediente():
                logger.error("  ✗ No se pudo ir a Accesos")
                outcome_obj = ProcessOutcome(
                    expediente=expediente,
                    row_idx=row_idx,
                    dependencia=dependencia,
                    outcome=Outcome.FAIL_UI,
                    reason="No se pudo navegar a Accesos"
                )
                outcomes.append(outcome_obj)
                update_result_fn(row_idx, "FAIL_ACCESOS")
                continue
            
            outcome, rc = driver.enter_expediente_change(ctx.expediente)
        else:
            # Primer expediente: sin Accesos
            logger.info(f"  Ingresando expediente inicial...")
            outcome, rc = driver.enter_expediente_initial(ctx.expediente)
            
            if outcome == Outcome.OK_RC:
                has_active_expediente = True
                logger.info(f"   Primer expediente válido encontrado")
                # --- Validación de EJECUTOR/INTERVENTOR (comparar con columna EJECUTOR del Excel) ---
                try:
                    if ctx.ejecutor:
                        assigned = driver.get_assigned_interventor(timeout=1.0) or ""
                        norm = lambda s: ''.join(c for c in (s or '').lower() if c.isalnum())
                        if not assigned:
                            logger.warning("   No se encontró interventor asignado en UI")
                            outcome_obj = ProcessOutcome(
                                expediente=expediente,
                                row_idx=row_idx,
                                dependencia=dependencia,
                                outcome=Outcome.SKIP_INTERVENTOR_INVALIDO,
                                reason="SIN INTERVENTOR ASIGNADO"
                            )
                            outcomes.append(outcome_obj)
                            update_result_fn(row_idx, "SIN INTERVENTOR ASIGNADO")
                            try:
                                if update_ejecutor_fn:
                                    update_ejecutor_fn(row_idx, "NO")
                            except Exception:
                                pass
                            # Limpiar campo y continuar con siguiente expediente
                            try:
                                driver.clear_expediente_field()
                            except Exception:
                                pass
                            continue
                        # Comparar nombres normalizados
                        if norm(assigned) != norm(ctx.ejecutor):
                            logger.warning(f"   Interventor diferente: UI='{assigned}' Excel='{ctx.ejecutor}'")
                            outcome_obj = ProcessOutcome(
                                expediente=expediente,
                                row_idx=row_idx,
                                dependencia=dependencia,
                                outcome=Outcome.SKIP_INTERVENTOR_INVALIDO,
                                reason="INTERVENTOR DIFERENTE"
                            )
                            outcomes.append(outcome_obj)
                            update_result_fn(row_idx, "INTERVENTOR DIFERENTE")
                            try:
                                if update_ejecutor_fn:
                                    update_ejecutor_fn(row_idx, "NO")
                            except Exception:
                                pass
                            try:
                                driver.clear_expediente_field()
                            except Exception:
                                pass
                            continue
                        else:
                            # Coincide el ejecutor/interventor
                            try:
                                if update_ejecutor_fn:
                                    update_ejecutor_fn(row_idx, "SI")
                            except Exception:
                                pass
                except Exception as e:
                    logger.debug(f"Error validando interventor: {e}")
            
            # IMPORTANTE: Si expediente fue validado (OK_RC), enviar Alt+A para continuar con embargo
            if outcome == Outcome.OK_RC:
                logger.info(f"  Enviando Alt+A para continuar con proceso de embargo...")
                import pyautogui
                import time as time_module
                pyautogui.hotkey('alt', 'a')
                time_module.sleep(1)
        
        # Si expediente inválido, continuar
        if outcome == Outcome.SKIP_EXP_INVALIDO:
            logger.warning(f"   Expediente inválido")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=outcome,
                reason="Expediente no válido en RSIRAT"
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, "EXP_INVALIDO")
            continue
        
        if outcome != Outcome.OK_RC or not has_active_expediente:
            # Error inesperado
            logger.error(f"  ✗ Error inesperado al ingresar expediente")
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=outcome if outcome else Outcome.FAIL_UI,
                reason="Error al ingresar expediente"
            )
            outcomes.append(outcome_obj)
            update_result_fn(row_idx, outcome_obj.outcome.name)
            continue
        
        # -------- Procesar según tipo --------
        logger.info(f"  Tipo de medida: {ctx.tipo_medida}")
        
        if "IEI" in ctx.tipo_medida:
            outcome_obj = process_iei(ctx, driver, logger)
        elif "DSE" in ctx.tipo_medida:
            outcome_obj = process_dse(ctx, driver, logger)
        else:
            outcome_obj = ProcessOutcome(
                expediente=expediente,
                row_idx=row_idx,
                dependencia=dependencia,
                outcome=Outcome.FAIL_UI,
                reason=f"Tipo desconocido: {ctx.tipo_medida}"
            )
        
        outcomes.append(outcome_obj)
        
        # Actualizar Excel
        if outcome_obj.outcome == Outcome.OK_RC and outcome_obj.rc_number:
            update_result_fn(row_idx, outcome_obj.outcome.name, outcome_obj.rc_number)
            logger.info(f"   RC guardada: {outcome_obj.rc_number}")
        else:
            update_result_fn(row_idx, outcome_obj.outcome.name)
            logger.warning(f"   {outcome_obj.outcome.name}: {outcome_obj.reason}")
    
    # -------- FASE 3: Cerrar app (solo si es última dependencia) --------
    if is_last:
        logger.info("\n[CLOSE] Cerrando aplicación...")
        driver.close_app()
        logger.info("   Aplicación cerrada")
    
    logger.info(f"\nDependencia {dependencia} completada: {len(outcomes)} expediente(s) procesado(s)")
    return outcomes


# ============================================================================
# PROCESOS ESPECÍFICOS POR TIPO
# ============================================================================
def process_iei(ctx: ContextoExpediente, driver: "AppDriver", logger: logging.Logger) -> ProcessOutcome:
    """Procesa un expediente tipo IEI (Intervención en Información)."""
    logger.info(f"  [IEI] Iniciando proceso...")
    
    # 1. Ir a Trabar Embargo
    if not driver.go_to_trabar_embargo():
        logger.error("  ✗ No se pudo ir a Trabar Embargo")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=Outcome.FAIL_UI,
            reason="No se pudo navegar a Trabar Embargo"
        )
    
    # 2. Click Trabar Intervención en Información
    if not driver.click_trabar_intervencion():
        logger.error("  ✗ No se pudo hacer clic en Trabar Intervención")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=Outcome.FAIL_UI,
            reason="No se pudo hacer clic en Trabar Intervención"
        )
    
    # 3. Ingresar INTERVENTOR
    outcome_int = driver.iei_enter_interventor(ctx.interventor)
    if outcome_int != Outcome.OK_RC:
        logger.warning(f"   Error en interventor: {outcome_int.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_int,
            reason="Código de interventor inválido"
        )
    
    # 4. Ingresar PLAZO y confirmar
    outcome_plazo, rc = driver.iei_set_plazo_and_confirm(ctx.plazo)
    if outcome_plazo != Outcome.OK_RC:
        logger.warning(f"   Error en plazo: {outcome_plazo.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_plazo,
            reason="Error al setear plazo o confirmar RC"
        )
    
    logger.info(f"   [IEI] Completado con RC={rc}")
    return ProcessOutcome(
        expediente=ctx.expediente,
        row_idx=ctx.row_idx,
        dependencia=ctx.dependencia,
        outcome=Outcome.OK_RC,
        rc_number=rc,
        reason="IEI completado exitosamente"
    )


def process_dse(ctx: ContextoExpediente, driver: "AppDriver", logger: logging.Logger) -> ProcessOutcome:
    """Procesa un expediente tipo DSE (Depósito Sin Extracción)."""
    logger.info(f"  [DSE] Iniciando proceso...")
    
    # 1. Ir a Trabar Embargo
    if not driver.go_to_trabar_embargo():
        logger.error("  ✗ No se pudo ir a Trabar Embargo")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=Outcome.FAIL_UI,
            reason="No se pudo navegar a Trabar Embargo"
        )
    
    # 2. Click Trabar Depósito sin Extracción
    if not driver.click_trabar_deposito():
        logger.error("  ✗ No se pudo hacer clic en Trabar Depósito")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=Outcome.FAIL_UI,
            reason="No se pudo hacer clic en Trabar Depósito"
        )
    
    # 3. Ingresar MONTO y confirmar
    outcome_monto, rc = driver.dse_set_monto_and_confirm(ctx.monto)
    
    if outcome_monto == Outcome.SKIP_MONTO_MAYOR:
        logger.warning(f"   Monto mayor que saldo")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_monto,
            reason="Monto excede saldo disponible"
        )
    
    if outcome_monto != Outcome.OK_RC:
        logger.warning(f"   Error en monto: {outcome_monto.name}")
        return ProcessOutcome(
            expediente=ctx.expediente,
            row_idx=ctx.row_idx,
            dependencia=ctx.dependencia,
            outcome=outcome_monto,
            reason="Error al procesar monto"
        )
    
    logger.info(f"   [DSE] Completado con RC={rc}")
    return ProcessOutcome(
        expediente=ctx.expediente,
        row_idx=ctx.row_idx,
        dependencia=ctx.dependencia,
        outcome=Outcome.OK_RC,
        rc_number=rc,
        reason="DSE completado exitosamente"
    )
