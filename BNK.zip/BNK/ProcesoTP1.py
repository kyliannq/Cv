import openpyxl
import pandas as pd 
from win32com.client import Dispatch
import time

#=============================================================================
# Función auxiliar para acceder a celdas (con o sin tabla)
#=============================================================================
class AccesoDatos:
    """Clase para acceder a datos en Excel, con o sin tabla definida"""
    def __init__(self, hojap, tabla=None):
        self.hojap = hojap
        self.tabla = tabla
        self.header_row = 1  # Fila de encabezados
    
    def get_valor(self, fila, columna):
        """Obtiene valor de celda (fila relativa 1-based)"""
        try:
            if self.tabla:
                return self.tabla.DataBodyRange.Rows(fila).Columns(columna).value
            else:
                # Acceso directo: header_row + fila
                celda = self.hojap.Cells(self.header_row + fila, columna)
                return celda.value
        except Exception as e:
            print(f"Error al obtener valor en fila {fila}, col {columna}: {e}")
            return None
    
    def set_valor(self, fila, columna, valor):
        """Establece valor en celda (fila relativa 1-based)"""
        try:
            if self.tabla:
                self.tabla.DataBodyRange.Rows(fila).Columns(columna).value = valor
            else:
                # Acceso directo: header_row + fila
                celda = self.hojap.Cells(self.header_row + fila, columna)
                celda.Value = valor
                # Forzar actualización
                celda.Application.ActiveWorkbook.Saved = False
        except Exception as e:
            print(f"Error al establecer valor en fila {fila}, col {columna}: {e}")


#=============================================================================
# Funcion auxiliar que verifica si los componentes del nombre son parte de un 
# apellido compuesto
#=============================================================================
def NACompuesto(texto):
    rpt_nacompuesto=[]
    try:
        arr = ["DE", "DEL", "LA", "LAS", "LOS", "SAN", "Y", "DA", "DI", "YE", "KU", "MC", "R", "XU", 
               "EL", "DU","MU", "YU", "JO", "O", "UN", "HU", "YI", "OU", "EX", "SO", "=-", "UM", "MO", "LU",
               "OC", "RU", "HO", "U", "LY", "FA", "D'", "NI", "AL", "GE", "HE", "FU", "QU", "LO", "-", "KI",
               "CH", "MA", "FO", "EP", "KO", "P","JA", "BO", "KA", "E.", "JI", "A", "O'", "WI", "IP", "JU", "VDA"]
        # arr = ["DE", "DEL", "LA", "LAS", "LOS", "SAN", "Y", "DA", "DI", "YE", "SU", "KU", "MC", "R", "XU", 
        #        "EL", "DU","MU", "YU", "JO", "O", "UN", "HU", "YI", "OU", "EX", "SO", "=-", "UM", "MO", "LU",
        #        "OC", "RU", "HO", "U", "LY", "FA", "D'", "NI", "AL", "GE", "HE", "FU", "QU", "LO", "-", "KI",
        #        "CH", "MA", "FO", "EP", "KO", "P","JA", "BO", "KA", "E.", "JI", "A", "O'", "WI", "IP", "JU", "VDA"]
        arr1=["DE","VDA"]
        resultadol=arr.index(texto)
        rpt_nacompuesto.append(bool(1))
        try:
            resultadol=arr1.index(texto)
            rpt_nacompuesto.append(bool(1))
            return rpt_nacompuesto
        except:
            rpt_nacompuesto.append(bool(0))
            return rpt_nacompuesto
    except:
        rpt_nacompuesto.append(bool(0))
        rpt_nacompuesto.append(bool(0))
        return rpt_nacompuesto

#==============================================================================
#=============================================================================
# Proceso para separar nombre de personas en en una lista de 3 columnas
#
#=============================================================================
def nombrePropio(valornommbre):
    aN1=[]
    apNombre=[["","",""],[0]]
    i=0
    valornommbre=valornommbre.strip()
    valornommbre = valornommbre.replace(".", " ")
    valornommbre = valornommbre.replace("  ", " ")
    aN1 = valornommbre.split(" ")
    l1 = len(aN1)
    j = 0
    k=0
    if l1 >3: # Se Cambia l1 > 2 por l1>3:
        while i<l1:
            if j==2:
                k=k+1
            if NACompuesto(aN1[i])[0]:
                if apNombre[0][j] == "":
                    apNombre[0][j] = aN1[i]
                else:
                    apNombre[0][j] = apNombre[0][j] + " " + aN1[i]
            else:
                if apNombre[0][j] == "":
                    apNombre[0][j] = aN1[i]
                    if j == 0:
                        j = j + 1
                    elif j==1 and i < l1: #se agrego "and i<l1" para evitar desbordamiento
                        if NACompuesto(aN1[i + 1])[0]:
                            j=j
                            if NACompuesto(aN1[i+1])[1]:
                                apNombre[1][0]=1
                        else:
                            j = j + 1
                else:
                    apNombre[0][j] = apNombre[0][j] + " " + aN1[i]
                    if j == 0:
                        j = j + 1
                    elif j == 1:
                        if i+1<l1:
                            if NACompuesto(aN1[i + 1])[0]:
                                j=j
                                if NACompuesto(aN1[i])[1]:
                                    apNombre[1][0]=1
                            else:
                                j = j + 1
            i=i+1
        if k>1:
            apNombre[1][0]=1
    elif l1 == 2:
        apNombre[0][0] = aN1[0]
        apNombre[0][2] = aN1[1]
        
    elif l1 == 3:
        apNombre[0][0] = aN1[0]
        apNombre[0][1] = aN1[1]  
        apNombre[0][2] = aN1[2] 
    return apNombre
#=============================================================================
#==============================================================================
# Generar Nombre de Busqueda:
# Completa Nombre de busqueda en Base_Contribuyente.xlsx
#==============================================================================
def completar_NB(areaR1,rutaCP,nombreA):
    nombreA=nombreA[0:len(nombreA)-5]
    excel_document_c = openpyxl.load_workbook(rutaCP +'\\'+ nombreA +'.xlsx')
    sheetc = excel_document_c.get_sheet_by_name('Base')
    excel_document1_c = pd.ExcelFile(rutaCP +'\\'+'Base_TipoC.xlsx') #openpyxl.load_workbook('Base_TipoC.xlsx') #Leer excel con panda
    sheetD1_c=excel_document1_c.parse('Relacion_C') #Leer relaciones
    i=2
    band=0
    valor=sheetc.cell(i, 2).value
    valor=valor.strip()
    sheetc.cell(i, 2).value=valor
    revisarnp=[[],[]]
    while valor != None:
        separador=sheetD1_c[sheetD1_c.Tipo_Contribuyente==sheetc.cell(i, 4).value]
        separador1=separador[separador.Tipo_S==1].Valor_Referencia
        separador0=separador[separador.Tipo_S==0].Valor_Referencia
        nombreB=sheetc.cell(i, 2).value
        if (sheetc.cell(i, 4).value =="PERSONA NATURAL CON NEGOCIO" or sheetc.cell(i, 
            4).value =="PERSONA NATURAL SIN NEGOCIO" or sheetc.cell(i, 4).value ==
           "SUCESION INDIVISA SIN NEGOCIO"):
            if str(areaR1)=='1':
                nombreB=nombreB.replace("SUCESION INDIVISA ","")
                nombreB=nombreB.replace("SUCESION INDIVISA DE ","")
                nombre=nombrePropio(nombreB)
                sheetc.cell(i, 3).value=nombre[0][0]+"|"+nombre[0][1]+"|"+nombre[0][2]
                if nombre[1][0]==1:
                    revisarnp[0].append(i)
                    revisarnp[1].append(sheetc.cell(i, 3).value)
                    
        else:
            a=len(valor)
            for separa in separador1: #separa variable de typo serie
                if nombreB.find(separa)>=0:
                   b=nombreB.index(separa)
                   sheetc.cell(i, 3).value=valor[0:b].strip()
                   band=1
                   break
            if band != 1:
                for separa in separador0: #separa variable de typo serie
                    if nombreB.find(separa)>=0:
                       b=nombreB.index(separa)
                       c= len(separa)
                       if a-(b+c)<2:
                           sheetc.cell(i, 3).value=valor[0:b].strip()
                           band=1
                           break  
                if band != 1:
                    sheetc.cell(i, 3).value=valor  
        i=i+1
        band=0
        valor=sheetc.cell(i, 2).value
        if valor  != None:
            valor=valor.strip()
        sheetc.cell(i, 2).value=valor
        #if i==3039:
        print (i)
    excel_document_c.save(rutaCP +'\\'+ nombreA +'_T.xlsx') #('Base_Contribuyente_Resultado.xlsx')
    for fila in revisarnp[0]:
        nombrea=revisarnp[1][revisarnp[0].index(fila)]
        nombrea=nombrea.split('|')
        nombrea1=nombrea[0]
        nombrea2=nombrea[1].split()
        nombreaa2=""
        nombrea3=nombrea[2].split()
        for n2 in range(len(nombrea2)):
            nombreaa2= nombreaa2 + " " + nombrea2[n2]
            nombreaa2=nombreaa2.strip()
            nombreaa3=""
            for n3 in range(len(nombrea3)):
                if n2!= len(nombrea2)-1 or n3!=len(nombrea3)-1:
                    nombreaa3= nombreaa3 + " " + nombrea3[n3]
                    nombreaa3=nombreaa3.strip()
                    sheetc.cell(i, 1).value=sheetc.cell(fila, 1).value
                    sheetc.cell(i, 2).value= nombrea1 + " " + nombreaa2 + " " + nombreaa3
                    sheetc.cell(i, 3).value= nombrea1 + "|" + nombreaa2 + "|" + nombreaa3
                    sheetc.cell(i, 4).value=sheetc.cell(fila, 4).value
                    i=i+1
    print(revisarnp)
    excel_document_c.save(rutaCP +'\\'+ nombreA +'_T.xlsx') #('Base_Contribuyente_Resultado.xlsx')
    excel_document_c.close()
    #py.alert("Proceso Terminado ",timeout=45800)#Mensaje de Inicio de sesion
#==============================================================================
#==============================================================================
# Generar Nombre de Busqueda:
# Completa Nombre de busqueda en Base_Contribuyente.xlsx
#==============================================================================
def completar_NB1(areaR1,rutaCP,carpeta_salida=None):
    diccionario={'1':['Base_Busqueda.xlsx'],'2':[''],'3':[''],
             '4':[''],'6':[''],'10':[''],
             '11':[''],'12':[''],'13':[''],'21':[''],'31':['']}
    nombreA=diccionario[str(areaR1)][0]
    nombreA=nombreA[0:len(nombreA)-5]
    xlApp = Dispatch("Excel.Application")
    xlApp.Visible = 0 # 1Indica visible, 0 No visible
    
    archivo_completo = rutaCP +'\\'+ nombreA +'.xlsx'
    print(f"Abriendo archivo: {archivo_completo}")
    
    try:
        xlAppL=xlApp.Workbooks.Open(archivo_completo)
        print("Archivo abierto correctamente")
    except Exception as e:
        print(f"Error al abrir archivo: {e}")
        xlApp.Quit()
        raise
    
    try:
        hojap=xlAppL.Sheets('Base')
        print("Hoja 'Base' encontrada")
    except Exception as e:
        print(f"Error: No se encontró la hoja 'Base'. Hojas disponibles:")
        for i in range(1, xlAppL.Sheets.Count + 1):
            print(f"  - {xlAppL.Sheets(i).Name}")
        xlAppL.Close()
        xlApp.Quit()
        raise
    
    # Intentar obtener la tabla o crearla si no existe
    tablaP = None
    print(f"Número de tablas definidas: {hojap.ListObjects.Count}")
    
    if hojap.ListObjects.Count > 0:
        tablaP = hojap.ListObjects(1)
        print("Tabla existente encontrada")
    else:
        # Crear tabla desde el rango usado
        print("No hay tablas definidas. Creando tabla desde rango usado...")
        try:
            used_range = hojap.UsedRange
            print(f"Rango usado: {used_range.Address}")
            xlApp.DisplayAlerts = False
            # Crear tabla automáticamente
            # Parámetros: SourceType (1=xlSrcRange), Source (rango), LinkSource (None), XlListObjectHasHeaders (1=True)
            tablaP = hojap.ListObjects.Add(1, used_range, None, 1)
            xlApp.DisplayAlerts = True
            print("Tabla creada exitosamente")
        except Exception as e:
            print(f"No se pudo crear tabla automáticamente: {e}")
            print("Intentando alternativa directo por celdas...")
            # Si no funciona, usaremos acceso directo
            tablaP = None
    excel_document1_c = pd.ExcelFile(rutaCP +'\\'+'Base_TipoC.xlsx') #openpyxl.load_workbook('Base_TipoC.xlsx') #Leer excel con panda
    sheetD1_c=excel_document1_c.parse('Relacion_C') #Leer relaciones
    
    # Crear acceso a datos
    datos = AccesoDatos(hojap, tablaP)
    
    i=1
    band=0
    valor=datos.get_valor(i, 3) #sheetc.cell(i, 2).value
    if valor is not None:
        valor=valor.strip()
        datos.set_valor(i, 3, valor)
    
    revisarnp=[[],[]]
    while valor != None:
        print('--->Transformar nombre fila ' + str(i))
        tipo_contribuyente = datos.get_valor(i, 4)
        separador=sheetD1_c[sheetD1_c.Tipo_Contribuyente==tipo_contribuyente]
        separador1=separador[separador.Tipo_S==1].Valor_Referencia
        separador0=separador[separador.Tipo_S==0].Valor_Referencia
        nombreB=datos.get_valor(i, 3)
        
        if (tipo_contribuyente =="PERSONA NATURAL CON NEGOCIO" or 
            tipo_contribuyente =="PERSONA NATURAL SIN NEGOCIO" or 
            tipo_contribuyente =="SOCIEDAD CONYUGAL SIN NEGOCIO" or 
            tipo_contribuyente =="SOCIEDAD CONYUGAL CON NEGOCIO" or 
            tipo_contribuyente == "SUCESION INDIVISA SIN NEGOCIO" or
            tipo_contribuyente == "SUCESION INDIVISA CON NEGOCIO"):
            if str(areaR1)=='1':
                if(tipo_contribuyente == "SUCESION INDIVISA SIN NEGOCIO" or
                   tipo_contribuyente == "SUCESION INDIVISA CON NEGOCIO"):
                    nombreB=nombreB.replace("SUCESION INDIVISA ","")
                    nombreB=nombreB.replace("SUCESION INDIVISA DE ","")
                    nombreB=nombreB.replace("SUCESION ","")
                nombre=nombrePropio(nombreB)
                datos.set_valor(i, 5, nombre[0][0]+"|"+nombre[0][1]+"|"+nombre[0][2])
                # if nombre[1][0]==1:
                #     revisarnp[0].append(i)
                #     revisarnp[1].append(datos.get_valor(i, 5))
                    
        else:
            a=len(valor)
            for separa in separador1: #separa variable de typo serie
                if nombreB.find(separa)>=0:
                   b=nombreB.index(separa)
                   datos.set_valor(i, 5, valor[0:b].strip())
                   band=1
                   break
            if band != 1:
                for separa in separador0: #separa variable de typo serie
                    if nombreB.find(separa)>=0:
                       b=nombreB.index(separa)
                       c= len(separa)
                       if a-(b+c)<2:
                           datos.set_valor(i, 5, valor[0:b].strip())
                           band=1
                           break  
                if band != 1:
                    datos.set_valor(i, 5, valor)  
        i=i+1
        band=0
        valor=datos.get_valor(i, 3)
        if valor  != None:
            valor=valor.strip()
            datos.set_valor(i, 3, valor)
        if i==201:
            i=i
        print (i)
    
    xlAppL.Save() #ActiveWorkbook
    
    # Inicializar columna Porcentaje con "0" para todas las filas válidas
    print("Inicializando columna Porcentaje con 0...")
    i = 1
    # Buscar última fila con datos en columna 1 (ITEM)
    ultima_fila_item = 1
    while datos.get_valor(i, 1) is not None:
        ultima_fila_item = i
        i = i + 1
    
    print(f"Última fila con datos: {ultima_fila_item}")
    
    # Llenar columna Porcentaje para todas las filas con datos
    print("Asignando 0 a todas las filas en Porcentaje...")
    for fila in range(1, ultima_fila_item + 1):
        # Verificar si hay datos en la fila
        valor_item = datos.get_valor(fila, 1)
        if valor_item is not None:
            # Asignar 0 a la columna Porcentaje (columna 6)
            datos.set_valor(fila, 6, 0)  # Usar número en lugar de string
            if fila % 10 == 0:  # Mostrar cada 10 filas
                print(f"Guardando progreso: Fila {fila}")
    
    # Guardar después de inicializar Porcentaje
    print(f"\nGuardando {ultima_fila_item} registros con Porcentaje = 0...")
    
    # Primera pasada de guardado
    xlAppL.Save()
    time.sleep(1)
    
    # Recalcular y asegurar que todo está guardado
    xlApp.Calculate()
    time.sleep(0.5)
    
    # Segunda pasada de guardado
    xlAppL.Save()
    time.sleep(0.5)
    
    # Segundo guardado para asegurar persistencia
    xlApp.DisplayAlerts = False
    if carpeta_salida:
        archivo_salida = carpeta_salida + '\\' + nombreA + '_T.xlsx'
        print(f"Guardando como: {archivo_salida}")
        # Guardar una vez más antes de SaveAs
        xlAppL.Save()
        time.sleep(0.5)
        # Ahora hacer SaveAs
        xlAppL.SaveAs(archivo_salida)
        time.sleep(1)  # Esperar a que se complete el guardado
        print(f"Archivo guardado exitosamente en: {archivo_salida}")
    else:
        xlAppL.Save()
        time.sleep(0.5)
        print(f"Archivo guardado")
    
    # Guardado final
    xlAppL.Save()
    time.sleep(0.5)
    
    xlApp.DisplayAlerts = True
    
    # Cerrar sin guardar cambios adicionales (ya guardamos)
    xlAppL.Close(SaveChanges=0)
    time.sleep(0.5)
    
    # Cerrar Excel
    xlApp.Quit()
    time.sleep(0.5)
    
    print("Proceso completado exitosamente")
    #py.alert("Proceso Terminado ",timeout=45800)#Mensaje de Inicio de sesion
#==============================================================================

