import tkinter as tk
import pandas as pd
import os
import pyautogui as py
import ProcesoTP1 as TP1
import Cajas as CJ
import openpyxl
import sqlite3
import difflib
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from tkinter import PhotoImage
from datetime import datetime

#Variable global para almacenar la carpeta de resultados
carpeta_salida_global = None

#==============================================================================
#Crear carpeta de resultados con timestamp
#==============================================================================
def crear_carpeta_resultados():
    global carpeta_salida_global
    if carpeta_salida_global is None:
        ruta_base = os.getcwd()
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        carpeta_botbanco = os.path.join(ruta_base, f"BOT_BANCO_{timestamp}")
        
        if not os.path.exists(carpeta_botbanco):
            os.makedirs(carpeta_botbanco)
        
        carpeta_salida_global = carpeta_botbanco
    
    return carpeta_salida_global

#==============================================================================
#Parametros de Iniciio
#Funcion que obtiene datos de parametros de inicio
#==============================================================================
def ParametrosInicio():
    global varInicial
    varInicial =[['Ruta del Aplicativo'],['']]
    varInicial[1][0]=os.getcwd() #Ruta del aplicativo
    path_varini=varInicial[1][0]+ '\\VariablesInicio.txt'  #r'.\usuario.txt' #Archivo de tipo txt donde se encuentra el nombre de usuario intranet
    abspath_usuario=os.path.abspath(path_varini)#Ruta del archivo txt   
    with open (abspath_usuario) as Usuario: # Variables Iniciales   
        for a,line in enumerate(Usuario):  #Leyedo usuario intranet
            valoresAux= line[0:len(line)-1].split('|')
            varInicial[0].append(valoresAux[0]) #Ingreso de nombre
            varInicial[1].append(valoresAux[1]) #Ingreso de valor
    
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def leerBaseDatos(arch, skiprows=0):
    baseData=[]
    rutaOrig=varInicial[1][0]
    rutaOrig=rutaOrig + '\Base_Datos'
    #archivosT01=os.listdir(rutaOrig)
    #print(archivosT01)
    #for arch in archivosT01:
    if arch[len(arch)-5:].lower()=='.xlsx':
        excel_of=pd.ExcelFile(rutaOrig +'\\' + arch) #Lee archivo excel
        hojaB=excel_of.parse(0,skiprows=skiprows,dtype =str)
        hojaB.fillna("", inplace = True)
        baseData.append([rutaOrig +'\\' + arch,arch,hojaB ])
        excel_of.close()
    elif arch[len(arch)-4:].lower()=='.txt':

        df = pd.read_csv(rutaOrig +'\\' + arch, sep="|",encoding='latin-1',keep_default_na=False
                         ,dtype =str)
        # Limpiar nombres de columnas: eliminar espacios al inicio y final
        df.columns = df.columns.str.strip()
        baseData.append([rutaOrig +'\\' + arch,arch,df])
    return  baseData
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def leerBaseDatos_1():
    baseData=[]
    rutaOrig=varInicial[1][0]
    rutaOrig=rutaOrig + '\Base_Datos'
    archivosT01=os.listdir(rutaOrig)
    #print(archivosT01)
    for arch in archivosT01:
        if arch[len(arch)-5:].lower()=='.xlsx':
            excel_of=pd.ExcelFile(rutaOrig +'\\' + arch) #Lee archivo excel
            hojaB=excel_of.parse(0,dtype =str)
            hojaB.fillna("", inplace = True)
            baseData.append([rutaOrig +'\\' + arch,arch,hojaB ])
            excel_of.close()
        elif arch[len(arch)-4:].lower()=='.txt':
            df = pd.read_csv(rutaOrig +'\\' + arch, sep="|",encoding='latin-1',keep_default_na=False
                             ,dtype =str)
            # Limpiar nombres de columnas: eliminar espacios al inicio y final
            df.columns = df.columns.str.strip()
            baseData.append([rutaOrig +'\\' + arch,arch,df])
    return  baseData
#==============================================================================
#==============================================================================
def PBusquedaP(areaR1):
    carpeta_salida = crear_carpeta_resultados()
    nombreBL='Base_Busqueda.xlsx'
    nombreHB='Base'
    nombreCBD='Base_Busqueda'
    nombreR="_R"
    areaR=areaR1
    skiprows_applied=0
    if areaR!=0:
        resultadosB=LeerResultados(nombreBL,nombreHB)
        if areaR==1:
            # NUEVA FUNCIÓN: Búsqueda en BANCOS con RESUMEN + DETALLE
            PBusquedaBancos(carpeta_salida)
            return
        elif areaR==2:
            # Usar la lógica de Cajas.py para búsqueda en base de datos SQLite
            PBusquedaCajas(resultadosB, carpeta_salida)
            return  # Salir sin procesar el guardado tradicional
        elif areaR==3:
            basetB=leerBaseDatos('3_TBL_MUNI_PREDIOS_2023.txt')
            BusquedaBProc2(basetB,resultadosB,['nombre'],skiprows_applied)
            BusquedaBRUC(basetB,resultadosB,'RUC_INFORMADO',skiprows_applied)
            nombreR="_R_TBL_MUNI_PREDIOS_2025"
        try: 
            excel_document_c = openpyxl.load_workbook(varInicial [1][0] + '\\' + nombreBL)
            sheetc = excel_document_c[nombreHB]#excel_document_c.get_sheet_by_name(nombreHB)
            j=2
            for i in resultadosB.index: 
                print("Guardar-->" + str(i))
                sheetc.cell(j, 6).value=resultadosB['Porcentaje'][i]
                print(len(resultadosB['Libro'][i]))
                if len(str(resultadosB['Libro'][i]))<= 320000:
                    sheetc.cell(j, 7).value=resultadosB['Libro'][i]
                else:
                    sheetc.cell(j, 7).value=str(resultadosB['Libro'][i])[0:320000]
                print(len(str(resultadosB['Hoja'][i]))<= 32000)
                if len(str(resultadosB['Hoja'][i]))<= 320000:
                    sheetc.cell(j, 8).value=resultadosB['Hoja'][i]
                else:
                    sheetc.cell(j, 8).value=str(resultadosB['Hoja'][i])[0:320000]
                if len(str(resultadosB['Fila'][i]))<= 320000:
                    sheetc.cell(j, 9).value=resultadosB['Fila'][i]
                else:
                    sheetc.cell(j, 9).value=str(resultadosB['Fila'][i])[0:320000]
                if len(str(resultadosB['Columna'][i]))<= 320000:
                    sheetc.cell(j, 10).value=resultadosB['Columna'][i]
                else:
                    sheetc.cell(j, 10).value=str(resultadosB['Columna'][i])[0:320000]
                    
                auxValorR=resultadosB['Valor'][i]
                if len(auxValorR)> 320000 :
                    auxValorR=auxValorR[0:320000]
                    
                auxValorR=ILLEGAL_CHARACTERS_RE.sub(r'',auxValorR)
                sheetc.cell(j, 11).value=str(auxValorR).encode("ascii",errors="ignore")
                j+=1
            archivo_resultado = os.path.join(carpeta_salida, nombreBL[0:len(nombreBL)-5] + nombreR + '.xlsx')
            excel_document_c.save(archivo_resultado)
            excel_document_c.close()
        except Exception as e:
            print("Se produjo un error")
            print(e)
            archivo_resultado = os.path.join(carpeta_salida, nombreBL[0:len(nombreBL)-5] + nombreR + '.xlsx')
            excel_document_c.save(archivo_resultado)
            excel_document_c.close()
#==============================================================================
#
#
#==============================================================================
def BusquedaBProc(basetB,resultadosB,Ffinal,skiprows_applied=0):
    try: 
        for fbasetB in basetB:
            # Usar iloc para evitar advertencias de pandas
            fbasetB[2] = fbasetB[2].fillna("")
        nombreP =[["","",""],[0]]
        for fbasetB in basetB:
            print('Proceso_BusquedaBProc_P_1_0')
            for b,nBuscar in enumerate(resultadosB['NOMBRE_BUSQUEDA']):
                try:
                    nBuscar=str(nBuscar).strip()
                    # Solo procesar si NOMBRE_BUSQUEDA tiene contenido
                    if len(nBuscar)>0:
                        # ====================================================================
                        # LÓGICA DE BÚSQUEDA CON NRO_DOC
                        # ====================================================================
                        nro_doc = str(resultadosB['NRO_DOC'][b]).strip() if 'NRO_DOC' in resultadosB.columns else ""
                        digitos_nro_doc = len([c for c in nro_doc if c.isdigit()])
                        
                        encontrado = False
                        
                        # CASO A: NRO_DOC con 8-9 dígitos (DNI/Carné)
                        if digitos_nro_doc == 8 or digitos_nro_doc == 9:
                            print(f'CASO A: NRO_DOC={nro_doc} ({digitos_nro_doc} dígitos) - Búsqueda en nro_doc')
                            try:
                                # Buscar tal cual como viene, sin normalizaciones
                                valoresAux = fbasetB[2][fbasetB[2]['nro_doc'].astype(str).str.strip() == nro_doc]
                                if len(valoresAux) > 0:
                                    print(f'CASO A: Encontrado en nro_doc (fila {valoresAux.index[0]})')
                                    auxP = 100
                                    LlenarResultados1(auxP, resultadosB, b, fbasetB[1], valoresAux.index[0], 'nro_doc',
                                                      valoresAux, 1, 1, '', '', '', skiprows_applied)
                                    encontrado = True
                                else:
                                    # Si no encuentra con formato exacto, intentar solo con dígitos
                                    solo_digitos = ''.join(filter(str.isdigit, nro_doc))
                                    db_solo_digitos = fbasetB[2]['nro_doc'].astype(str).apply(lambda x: ''.join(filter(str.isdigit, x)))
                                    valoresAux = fbasetB[2][db_solo_digitos == solo_digitos]
                                    if len(valoresAux) > 0:
                                        print(f'CASO A: Encontrado por coincidencia de dígitos en nro_doc (fila {valoresAux.index[0]})')
                                        auxP = 100
                                        LlenarResultados1(auxP, resultadosB, b, fbasetB[1], valoresAux.index[0], 'nro_doc',
                                                          valoresAux, 1, 1, '', '', '', skiprows_applied)
                                        encontrado = True
                            except Exception as e:
                                print(f'CASO A: Error en búsqueda de nro_doc - {str(e)}')
                        
                        # CASO B: NRO_DOC con 11 dígitos (RUC)
                        elif digitos_nro_doc == 11:
                            print(f'CASO B: NRO_DOC={nro_doc} ({digitos_nro_doc} dígitos) - Búsqueda en RUC_INFORMADO')
                            try:
                                valoresAux = fbasetB[2][fbasetB[2]['RUC_INFORMADO'].astype(str).str.strip() == nro_doc]
                                if len(valoresAux) > 0:
                                    print(f'CASO B: Encontrado en RUC_INFORMADO (fila {valoresAux.index[0]})')
                                    auxP = 100
                                    LlenarResultados1(auxP, resultadosB, b, fbasetB[1], valoresAux.index[0], 'RUC_INFORMADO',
                                                      valoresAux, 1, 1, '', '', '', skiprows_applied)
                                    encontrado = True
                            except Exception as e:
                                print(f'CASO B: Error en búsqueda de RUC_INFORMADO - {str(e)}')
                        
                        # CASO C: NRO_DOC inválido, vacío u otro - Fallback a NOMBRE_BUSQUEDA
                        if not encontrado:
                            print(f'CASO C: Fallback a búsqueda por NOMBRE_BUSQUEDA (encontrado={encontrado})')
                            # Convertir NRO_DOC a string para evitar errores de tipo
                            nro_doc_str = str(resultadosB['NRO_DOC'][b]).strip()
                            ruc_str = nro_doc_str
                            if len(ruc_str)==11 and ruc_str[0:1]=='2':
                                nombreP[0][0]=nBuscar
                                idB=1
                                colB1=Ffinal[3]
                                colB2=''
                                colB3=''
                                a=6
                            else:
                               nombreP[0]=nBuscar.split('|')
                               # Validar que tenemos al menos 3 elementos después del split
                               if len(nombreP[0]) < 3:
                                   # Rellenar con cadenas vacías si faltan elementos
                                   while len(nombreP[0]) < 3:
                                       nombreP[0].append('')
                               idB=0
                               a=4
                               colB1=Ffinal[0]
                               colB2=Ffinal[1]
                               colB3=Ffinal[2]
                            apellidoC=nombreP[0][0] #+ ' ' + nombreP[0][1]
                            nombreC=nombreP[0][2].split(' ') if nombreP[0][2] else ['']
                            nombreCC= apellidoC +' ' + nombreP[0][2]
                            longitudN=len(nombreP[0][2])
                            longitudAp=len(apellidoC)
                            print('Proceso_BusquedaBProc_P_1_1' + '-->'+str(b))
                            valoresAux= fbasetB[2][fbasetB[2][colB1].str.contains(apellidoC,case=False)]#,regex=False)] # 
                            print(fbasetB[0],fbasetB[1],apellidoC,b,len(valoresAux))
                            if len(valoresAux)>0: 
                                print('Proceso_BusquedaBProc_P_1_1_1' + '-->'+colB1 + '--'+str(b))
                                if idB==0:
                                    print('Proceso_BusquedaBProc_P_1_1_2' + '-->')
                                    valoresV=valoresAux
                                    valoresAux1= valoresAux[valoresAux[colB2].str.contains(nombreP[0][1],case=False)]#,regex=False)]
                                    auxP=0
                                    if len(valoresAux1)>0:
                                        print('Proceso_BusquedaBProc_P_1_1_3' + '-->')
                                        valoresV=valoresAux1
                                        auxP=40
                                        valoresAux2= valoresAux1[valoresAux1[colB3].str.contains(nombreP[0][2],case=False)]#,regex=False)]
                                        if len(valoresAux2)>0:
                                            print('Proceso_BusquedaBProc_P_1_1_4' + '-->')
                                            valoresV=valoresAux2
                                            auxP=60
                                            for filB, apP,apM,nombC in zip(valoresAux2.index,valoresAux2[colB1],
                                                                           valoresAux2[colB2],valoresAux2[colB3]):
                                                if apP.upper()==nombreP[0][0].upper() and apM.upper()==nombreP[0][1].upper() and nombC.upper()==nombreP[0][2].upper():
                                                    auxP=100
                                                    LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                                                      valoresV, a,idB,colB2,colB3,Ffinal[4],skiprows_applied)
                                                    break
                                            LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                                              valoresV, a,idB,colB2,colB3,Ffinal[4],skiprows_applied)
                                        else:
                                            LlenarResultados1(auxP,resultadosB,b,fbasetB[1],valoresV.index[0],colB1,
                                                  valoresV, a,idB,colB2,colB3,Ffinal[4],skiprows_applied)
                                        
                                else:
                                    print('Proceso_BusquedaBProc_P_1_1_2' + '-->')
                                    valoresV=valoresAux
                                    auxP=60
                                    for filB, apP in zip(valoresAux.index,valoresAux[colB1]):
                                        if apP.upper()==nombreP[0][0].upper():
                                            auxP=100
                                            LlenarResultados1(auxP,resultadosB,b,fbasetB[1],filB,colB1,
                                                  valoresV, a,idB,colB2,colB3,Ffinal[4],skiprows_applied)
                                
                                          
                            else:
                                auxP=0
                                if resultadosB['Porcentaje'][b]=="":
                                    resultadosB.loc[b, 'Porcentaje']=str(auxP)
                    else:
                        # Fila vacía, continuar con la siguiente
                        print(f'Fila {b} vacía, saltando...')
                        continue
                except Exception as e:
                    print(f'Error en fila {b}: {str(e)}')
                    # Continuar sin parar la búsqueda
                    continue
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================
#==============================================================================
#
#
#==============================================================================
def BusquedaBProc2(basetB,resultadosB,Ffinal,skiprows_applied=0):
    """
    Búsqueda para MUNICIPIOS (3_TBL_MUNI_PREDIOS)
    CASO A: Buscar en nro_doc (exactitud)
    CASO B: Si no encuentra, buscar en RUC_INFORMADO (exactitud)
    CASO C: Si no encuentra, buscar en 'nombre' (similitud)
    """
    try: 
        for fbasetB in basetB:
            # Usar fillna sin inplace para evitar advertencias de pandas
            fbasetB[2] = fbasetB[2].fillna("")
        
        for fbasetB in basetB:
            print('Proceso_BusquedaBProc2_P_1_0 - MUNICIPIOS')
            for b,nBuscar in enumerate(resultadosB['NOMBRE_BUSQUEDA']):
                try:
                    nBuscar=str(nBuscar).strip()
                    # Solo procesar si NOMBRE_BUSQUEDA tiene contenido
                    if len(nBuscar)>0:
                        encontrado = False
                        
                        # Leer NRO_DOC
                        nro_doc = str(resultadosB['NRO_DOC'][b]).strip() if 'NRO_DOC' in resultadosB.columns else ""
                        
                        # ====================================================================
                        # CASO A: Buscar en nro_doc (búsqueda exacta, sin restricción dígitos)
                        # ====================================================================
                        if len(nro_doc) > 0:
                            print(f'CASO A (MUNICIPIOS): Buscando nro_doc={nro_doc}')
                            try:
                                valoresAux = fbasetB[2][fbasetB[2]['nro_doc'].astype(str).str.strip() == nro_doc]
                                if len(valoresAux) > 0:
                                    print(f'CASO A: ¡Encontrado en nro_doc!')
                                    auxP = 100
                                    LlenarResultados(auxP, resultadosB, b, fbasetB[1], valoresAux.index[0], 'nro_doc',
                                                     valoresAux, 1, skiprows_applied)
                                    encontrado = True
                            except Exception as e:
                                print(f'CASO A: Error - {str(e)}')
                        
                        # ====================================================================
                        # CASO B: Si no encontró en CASO A, buscar en RUC_INFORMADO (exactitud)
                        # ====================================================================
                        if not encontrado and len(nro_doc) > 0:
                            print(f'CASO B (MUNICIPIOS): Buscando RUC_INFORMADO={nro_doc}')
                            try:
                                valoresAux = fbasetB[2][fbasetB[2]['RUC_INFORMADO'].astype(str).str.strip() == nro_doc]
                                if len(valoresAux) > 0:
                                    print(f'CASO B: ¡Encontrado en RUC_INFORMADO!')
                                    auxP = 100
                                    LlenarResultados(auxP, resultadosB, b, fbasetB[1], valoresAux.index[0], 'RUC_INFORMADO',
                                                     valoresAux, 1, skiprows_applied)
                                    encontrado = True
                            except Exception as e:
                                print(f'CASO B: Error - {str(e)}')
                        
                        # ====================================================================
                        # CASO C: Búsqueda por similitud combinada (ape_pat + ape_mat + nombre)
                        # Si hay múltiples coincidencias >= 80%, devuelve TODAS
                        # ====================================================================
                        if not encontrado:
                            print(f'CASO C (MUNICIPIOS): Búsqueda por similitud combinada')
                            
                            # Construir nombre completo uniendo los 3 componentes
                            nombreP = nBuscar.split('|')
                            nombre_busqueda = ' '.join([p.strip() for p in nombreP if p.strip()])
                            componentes = [p.strip().upper() for p in nombreP if p.strip()]
                            print(f'Nombre completo a buscar: "{nombre_busqueda}"')
                            print(f'Componentes: {componentes}')
                            
                            try:
                                # Verificar que la columna 'nombre' existe
                                if 'nombre' not in fbasetB[2].columns:
                                    print(f'CASO C: Columna "nombre" no encontrada')
                                    auxP = 0
                                    if resultadosB['Porcentaje'][b] == "":
                                        resultadosB.loc[b, 'Porcentaje'] = str(auxP)
                                else:
                                    # PASO 1: Filtrar registros que contengan AL MENOS UN componente
                                    registros_filtrados = fbasetB[2].copy()
                                    
                                    # Si hay componentes, filtrar por ellos
                                    if len(componentes) > 0:
                                        # Crear filtro: registros que contengan al menos un componente importante
                                        filtro = pd.Series([False] * len(registros_filtrados))
                                        for comp in componentes[:2]:  # Filtrar por los 2 primeros (apellidos)
                                            if len(comp) > 2:  # Solo componentes significativos
                                                filtro |= registros_filtrados['nombre'].astype(str).str.contains(comp, case=False, na=False)
                                        
                                        # Si el filtro tiene resultados, usar eso; si no, usar todo (fallback)
                                        if filtro.sum() > 0:
                                            registros_filtrados = registros_filtrados[filtro]
                                            print(f'CASO C: Filtrados a {len(registros_filtrados)} registros (contienen componentes)')
                                        else:
                                            print(f'CASO C: Sin coincidencias de apellidos, buscando en todos ({len(registros_filtrados)} registros)')
                                    
                                    # PASO 2: Calcular similitud solo en registros filtrados
                                    similitudes = []
                                    nombre_busqueda_upper = nombre_busqueda.upper()
                                    
                                    print(f'CASO C: Calculando similitud en {len(registros_filtrados)} registros...')
                                    for idx, fila in registros_filtrados.iterrows():
                                        nombre_fila = str(fila['nombre']).strip()
                                        
                                        if nombre_fila:
                                            # Usar SequenceMatcher
                                            matcher = difflib.SequenceMatcher(None, nombre_busqueda_upper, nombre_fila.upper())
                                            ratio = matcher.ratio() * 100
                                            
                                            similitudes.append({
                                                'indice': idx,
                                                'nombre': nombre_fila,
                                                'similitud': ratio
                                            })
                                    
                                    if similitudes:
                                        # Ordenar por similitud descendente
                                        similitudes.sort(key=lambda x: x['similitud'], reverse=True)
                                        mejor = similitudes[0]
                                        
                                        # PASO 3: Umbral mínimo (80%)
                                        if mejor['similitud'] >= 80:
                                            print(f"CASO C: Mejor coincidencia: '{mejor['nombre']}' (Similitud: {mejor['similitud']:.1f}%)")
                                            auxP = int(mejor['similitud'])
                                            
                                            # PASO 4: Obtener TODAS las coincidencias >= 80%
                                            coincidencias_buenas = [s for s in similitudes if s['similitud'] >= 80]
                                            print(f'CASO C: Encontradas {len(coincidencias_buenas)} coincidencia(s) >= 80%')
                                            
                                            # Procesar cada coincidencia
                                            for i, coincidencia in enumerate(coincidencias_buenas):
                                                similitud_actual = int(coincidencia['similitud'])
                                                print(f'  [{i+1}] {coincidencia["nombre"]} - {coincidencia["similitud"]:.1f}%')
                                                
                                                # Crear slice del DataFrame con este registro
                                                valoresAux = fbasetB[2].iloc[coincidencia['indice']:coincidencia['indice']+1]
                                                
                                                if i == 0:
                                                    # Primera coincidencia: LlenarResultados normal (llena Libro, Hoja, Valor, Fila, Columna)
                                                    LlenarResultados(similitud_actual, resultadosB, b, fbasetB[1], coincidencia['indice'], 'nombre',
                                                                   valoresAux, 1, skiprows_applied)
                                                else:
                                                    # Coincidencias adicionales: solo concatena Valor, Fila, Columna (NO Libro/Hoja)
                                                    AgregarCoincidenciaAdicional(resultadosB, b, coincidencia['indice'], 'nombre',
                                                                               valoresAux, skiprows_applied)
                                            
                                            encontrado = True
                                        else:
                                            print(f'CASO C: Similitud insuficiente ({mejor["similitud"]:.1f}% < 80%)')
                                            auxP = 0
                                            if resultadosB['Porcentaje'][b] == "":
                                                resultadosB.loc[b, 'Porcentaje'] = str(auxP)
                                    else:
                                        print(f'CASO C: Sin registros para comparar')
                                        auxP = 0
                                        if resultadosB['Porcentaje'][b] == "":
                                            resultadosB.loc[b, 'Porcentaje'] = str(auxP)
                            except Exception as e:
                                print(f'CASO C: Error en búsqueda de similitud - {str(e)}')
                                auxP = 0
                                if resultadosB['Porcentaje'][b] == "":
                                    resultadosB.loc[b, 'Porcentaje'] = str(auxP)
                    else:
                        # NOMBRE_BUSQUEDA está vacío, saltar esta fila
                        print(f'Fila {b}: NOMBRE_BUSQUEDA vacío, saltando...')
                        continue
                except Exception as e:
                    print(f'Error en fila {b}: {str(e)}')
                    # Continuar sin parar la búsqueda
                    continue
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================
#==============================================================================
#
#
#==============================================================================
def BusquedaBRUC(basetB,resultadosB,colRUC,skiprows_applied=0):
    try: 
        for fbasetB in basetB:
            # Usar fillna sin inplace para evitar advertencias de pandas
            fbasetB[2] = fbasetB[2].fillna("")
        nombreP =[["","",""],[0]]
        for fbasetB in basetB:
            print('BusquedaBRUC_P_1_0')
            for b,nBuscar in enumerate(resultadosB['NRO_DOC']):
                try:
                    # Convertir nBuscar a string para evitar errores de tipo
                    nBuscar = str(nBuscar).strip()
                    # Solo procesar si NRO_DOC tiene contenido
                    if len(nBuscar)>0:
                        # Convertir NRO_DOC a string para evitar errores de tipo
                        ruc_str = str(resultadosB['NRO_DOC'][b]).strip()
                        if len(ruc_str)==11 and ruc_str[0:1]=='2':
                            nombreP[0][0]=nBuscar
                            idB=1
                            colB1=colRUC
                            a=1
                        else:
                            nombreP[0]=nBuscar.split('|')
                            idB=0
                            a=1
                            colB1=colRUC
                        apellidoC=nombreP[0][0]  #+ ' ' + nombreP[0][1]
                        if apellidoC!='SN' and apellidoC!='-':
                            print('PBusquedaBRUC_P_1_1' + '-->'+str(b))
                            valoresAux= fbasetB[2][fbasetB[2][colB1].str.contains(apellidoC,case=False)] # 
                            print(fbasetB[0],fbasetB[1],apellidoC,b,len(valoresAux))
                            if len(valoresAux)>0: 
                                print('BusquedaBRUC_P_1_1_1' + '-->'+colB1 + '--'+str(b))
                                if idB==0:
                                    valoresV=valoresAux
                                    auxP=60
                                    for a1,nrevisar in zip(valoresAux.index,valoresAux[colB1]):
                                        print('BusquedaBRUC_P_1_1_2' + '_'+str(a1))
                                        filaE=a1
                                        if nrevisar.upper()==apellidoC.upper():
                                            auxP=100
                                            LlenarResultados(auxP, resultadosB,b,fbasetB[1],
                                                 filaE,colB1,valoresV, a,skiprows_applied)
                                        
                                else:
                                    valoresV=valoresAux
                                    auxP=100
                                    filaE=valoresV.index[0]
                                    LlenarResultados(auxP, resultadosB,b,fbasetB[1],
                                                 filaE,colB1,valoresV,a,skiprows_applied)
                                    
                                
                    else:
                        # RUC está vacío, saltar esta fila
                        print(f'Fila {b}: RUC vacío, saltando...')
                        auxP=0
                        if resultadosB['Porcentaje'][b]=="":
                            resultadosB.loc[b, 'Porcentaje']=str(auxP)
                except Exception as e:
                    print(f'Error en fila {b} (RUC): {str(e)}')
                    # Continuar sin parar la búsqueda
                    continue
    except Exception as e:
        print('Se genero un error -->')
        print(e)
#==============================================================================
#==============================================================================
# Función para eliminar Base de Datos de Cajas
#==============================================================================
def EliminarBaseDatos():
    """
    Elimina la base de datos Base_Datos_Proceso.db
    """
    try:
        ruta_base = varInicial[1][0]
        base_p = ruta_base + r"\Base_Datos\Base_Datos_Proceso.db"
        
        if os.path.exists(base_p):
            # Intentar eliminar el archivo
            try:
                os.remove(base_p)
                py.alert("Base de datos eliminada exitosamente.\nPuede cargar nuevos datos.", timeout=1600)
                print(f"Archivo eliminado: {base_p}")
            except PermissionError:
                py.alert("ERROR: No se puede eliminar el archivo.\nVerifique que no esté en uso.", timeout=1600)
                print("Permiso denegado al intentar eliminar el archivo")
            except Exception as e:
                py.alert(f"ERROR al eliminar la base de datos:\n{str(e)}", timeout=1600)
                print(f"Error: {str(e)}")
        else:
            py.alert("La base de datos no existe.", timeout=1600)
            print(f"Archivo no encontrado: {base_p}")
    except Exception as e:
        print(f"Error en EliminarBaseDatos: {str(e)}")
        py.alert(f"Error al eliminar base de datos:\n{str(e)}")

#==============================================================================
#==============================================================================
# Búsqueda en bases de datos SQLite de Cajas
#==============================================================================
def PBusquedaCajas(resultadosB, carpeta_salida):
    """
    Realiza búsqueda en base de datos SQLite de Cajas.
    Verifica si los datos están cargados y los carga si es necesario.
    """
    try:
        # Rutas de archivos
        ruta_base = varInicial[1][0]
        archivo_202501_202506 = ruta_base + r"\Base_Datos\2_CAJAS_CREDDESEMBOLSADOS_202501_202506.txt"
        archivo_202507_202512 = ruta_base + r"\Base_Datos\2_CAJAS_CREDDESEMBOLSADOS_202507_202512.txt"
        base_p = ruta_base + r"\Base_Datos\Base_Datos_Proceso.db"
        nombre_tabla = "BANCOS_CAJAS_CREDDESEMBOLSADOS"
        
        # Verificar si existen los archivos TXT
        archivo_1_existe = os.path.exists(archivo_202501_202506)
        archivo_2_existe = os.path.exists(archivo_202507_202512)
        
        if not archivo_1_existe and not archivo_2_existe:
            py.alert("ERROR: No se encontraron los archivos de datos de Cajas\nEsperados:\n" +
                    archivo_202501_202506 + "\n" + archivo_202507_202512)
            return
        
        # Obtener períodos ya cargados
        periodos_cargados = CJ.ObtenerPeriodosDisponibles(base_p)
        periodos_a_cargar = []
        
        print(f"Períodos cargados: {periodos_cargados}")
        
        # Verificar qué datos necesitan ser cargados
        if archivo_1_existe and "2025_01_06" not in periodos_cargados:
            periodos_a_cargar.append(("2025_01_06", archivo_202501_202506))
        
        if archivo_2_existe and "2025_07_12" not in periodos_cargados:
            periodos_a_cargar.append(("2025_07_12", archivo_202507_202512))
        
        # Cargar datos si es necesario
        if periodos_a_cargar:
            print(f"Cargando {len(periodos_a_cargar)} período(s) en SQLite...")
            for periodo, archivo in periodos_a_cargar:
                try:
                    print(f"  - Cargando período {periodo}...")
                    CJ.CargarDataBaseSQLite(archivo, base_p, nombre_tabla, periodo)
                    CJ.GuardarPeriodoCargado(base_p, periodo)
                    
                    # SOLUCIÓN 1: Crear índices para acelerar búsquedas (mejora 10-100x)
                    print(f"  - Creando índices para período {periodo}...")
                    CJ.CrearIndicesSQLite(base_p, nombre_tabla, periodo)
                    
                    print(f"   Período {periodo} cargado y optimizado exitosamente")
                except Exception as e:
                    print(f"   Error cargando período {periodo}: {str(e)}")
                    py.alert(f"Error al cargar datos de Cajas ({periodo}):\n{str(e)}")
                    return
        
        # Obtener períodos finales disponibles
        periodos_cargados = CJ.ObtenerPeriodosDisponibles(base_p)
        
        if not periodos_cargados:
            py.alert("ERROR: No hay datos cargados en la base de datos SQLite")
            return
        
        print(f"Iniciando búsqueda en períodos: {periodos_cargados}")
        
        # Ejecutar búsqueda en Cajas
        nomb_archivo_busqueda = ruta_base + r"\Base_Busqueda.xlsx"
        parametros = ["nom_aplpatpre", "nom_aplmatpre", "nom_pre", "nom_razpre"]
        
        # Procesar búsqueda usando función de Cajas.py (guardar reportes en carpeta_salida)
        CJ.procesobusuqeda(base_p, nomb_archivo_busqueda, nombre_tabla, parametros, carpeta_salida, periodos_cargados)
        
        py.alert(f"Búsqueda en Cajas completada.\nPeríodos: {', '.join(periodos_cargados)}\nReportes en: {carpeta_salida}")
        
    except Exception as e:
        print(f"Error en PBusquedaCajas: {str(e)}")
        py.alert(f"Error en búsqueda de Cajas:\n{str(e)}")

#==============================================================================

#==============================================================================
# Función auxiliar para agregar coincidencias adicionales sin repetir Libro/Hoja
# Solo para MUNICIPIOS (CASO C) con múltiples coincidencias
#==============================================================================
def AgregarCoincidenciaAdicional(resultadosB, fila, filaE, colB1, valoresAux, skiprows_applied=0):
    """
    Agrega una coincidencia adicional sin repetir Libro/Hoja.
    Solo concatena Valor, Fila, Columna con "|"
    """
    b = fila
    row_offset = skiprows_applied + 2
    
    fila_actual = str(filaE + row_offset)
    columna_actual = "2"  # Columna siempre es 2 para nombre
    valor_actual = valoresAux[colB1][filaE]
    
    # Obtener listas actuales
    filas_list = resultadosB.loc[b, 'Fila'].split('|')
    columnas_list = resultadosB.loc[b, 'Columna'].split('|')
    valores_list = resultadosB.loc[b, 'Valor'].split('|')
    
    # Agregar solo si no existe duplicado
    if fila_actual not in filas_list:
        filas_list.append(fila_actual)
    if columna_actual not in columnas_list:
        columnas_list.append(columna_actual)
    if valor_actual not in valores_list:
        valores_list.append(valor_actual)
    
    # Actualizar SOLO Fila, Columna, Valor (NO Libro ni Hoja)
    resultadosB.loc[b, 'Fila'] = '|'.join(filas_list)
    resultadosB.loc[b, 'Columna'] = '|'.join(columnas_list)
    resultadosB.loc[b, 'Valor'] = '|'.join(valores_list)

#==============================================================================
#
#==============================================================================
def validar_porcentaje(porcentaje_str):
    """Convierte porcentaje a entero, maneja casos de cadena vacía o None"""
    if porcentaje_str == '' or porcentaje_str is None:
        return 0
    try:
        return int(porcentaje_str)
    except ValueError:
        return 0

#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#def LlenarResultados(Porcentaje_resultado,Base_Resultado,Fila_Resultado
#,Nombre_Base,Fila_Encontrado_Base,Columna_Busqueda,Base_Busuqeda,Columna_B
#==============================================================================
def LlenarResultados(porcentaje, resultadosB,fila,libro,filaE,colB1,valoresAux, colI,skiprows_applied=0):
    auxP=porcentaje
    b=fila
    a=colI
    row_offset=skiprows_applied+2
    #a=filab
    if auxP>=60:
        print('LlenarResultados_P_1_1' + '-->' + str(b))
        if validar_porcentaje(resultadosB.loc[b, 'Porcentaje'])<60:
            resultadosB.loc[b, 'Libro']=""
            resultadosB.loc[b, 'Hoja']=""
            resultadosB.loc[b, 'Fila']=""
            resultadosB.loc[b, 'Columna']=""
            resultadosB.loc[b, 'Valor']=""
        if resultadosB.loc[b, 'Libro']=="":
            resultadosB.loc[b, 'Libro']=libro
            resultadosB.loc[b, 'Hoja']=libro
            resultadosB.loc[b, 'Fila']=str(filaE+row_offset)
            resultadosB.loc[b, 'Columna']=str(a+1)
            resultadosB.loc[b, 'Valor']=valoresAux[colB1][filaE]
        else:
            # Concatenar y deduplicar valores
            fila_actual = str(filaE+row_offset)
            columna_actual = str(a+1)
            valor_actual = valoresAux[colB1][filaE]
            
            filas_list = resultadosB.loc[b, 'Fila'].split('|')
            columnas_list = resultadosB.loc[b, 'Columna'].split('|')
            valores_list = resultadosB.loc[b, 'Valor'].split('|')
            
            # Agregar solo si no existe duplicado
            if fila_actual not in filas_list:
                filas_list.append(fila_actual)
            if columna_actual not in columnas_list:
                columnas_list.append(columna_actual)
            if valor_actual not in valores_list:
                valores_list.append(valor_actual)
            
            resultadosB.loc[b, 'Libro']=resultadosB.loc[b, 'Libro'] + '|' + libro
            resultadosB.loc[b, 'Hoja']=resultadosB.loc[b, 'Hoja'] + '|' + libro
            resultadosB.loc[b, 'Fila']='|'.join(filas_list)
            resultadosB.loc[b, 'Columna']='|'.join(columnas_list)
            resultadosB.loc[b, 'Valor']='|'.join(valores_list)
        if auxP>validar_porcentaje(resultadosB.loc[b, 'Porcentaje']):
            resultadosB.loc[b, 'Porcentaje']=str(auxP)
    else:
        print('LlenarResultados_P_1_2'  + '-->' + str(b))
        if auxP>validar_porcentaje(resultadosB.loc[b, 'Porcentaje']):
            resultadosB.loc[b, 'Porcentaje']=str(auxP)
            if resultadosB.loc[b, 'Libro']=="":
                resultadosB.loc[b, 'Libro']=libro #fbasetB[0]
                resultadosB.loc[b, 'Hoja']=libro
                resultadosB.loc[b, 'Fila']=str(filaE)
                resultadosB.loc[b, 'Columna']=str(a+1)
                resultadosB.loc[b, 'Valor']= valoresAux[colB1][filaE]
            else:
                # Concatenar y deduplicar valores
                fila_actual = str(filaE)
                columna_actual = str(a+1)
                valor_actual = valoresAux[colB1][filaE]
                
                filas_list = resultadosB.loc[b, 'Fila'].split('|')
                columnas_list = resultadosB.loc[b, 'Columna'].split('|')
                valores_list = resultadosB.loc[b, 'Valor'].split('|')
                
                # Agregar solo si no existe duplicado
                if fila_actual not in filas_list:
                    filas_list.append(fila_actual)
                if columna_actual not in columnas_list:
                    columnas_list.append(columna_actual)
                if valor_actual not in valores_list:
                    valores_list.append(valor_actual)
                
                resultadosB.loc[b, 'Libro']=resultadosB.loc[b, 'Libro'] + '|' + libro
                resultadosB.loc[b, 'Hoja']=resultadosB.loc[b, 'Hoja'] + '|' + libro
                resultadosB.loc[b, 'Fila']='|'.join(filas_list)
                resultadosB.loc[b, 'Columna']='|'.join(columnas_list)
                resultadosB.loc[b, 'Valor']='|'.join(valores_list)
        else:
            pass
                                
#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#def LlenarResultados(Porcentaje_resultado,Base_Resultado,Fila_Resultado
#,Nombre_Base,Fila_Encontrado_Base,Columna_Busqueda,Base_Busuqeda,Columna_B
#==============================================================================
def LlenarResultados1(porcentaje, resultadosB,fila,libro,filaE,colB1,
                      valoresV, colI,idB,colB2,colB3,colND,skiprows_applied=0):
    auxP=porcentaje
    b=fila
    a=colI
    row_offset=skiprows_applied+2
    if auxP>=40:
        print('LlenarResultados1_P_1_1' + '-->'+str(fila))
        if validar_porcentaje(resultadosB.loc[b, 'Porcentaje'])<40:
            resultadosB.loc[b, 'Libro']=""
            resultadosB.loc[b, 'Hoja']=""
            resultadosB.loc[b, 'Fila']=""
            resultadosB.loc[b, 'Columna']=""
            resultadosB.loc[b, 'Valor']=""
        if resultadosB.loc[b, 'Libro']=="":
            resultadosB.loc[b, 'Libro']=libro
            resultadosB.loc[b, 'Hoja']=libro
            resultadosB.loc[b, 'Fila']=str(filaE+row_offset) #str(a+1)
            resultadosB.loc[b, 'Columna']=str(a+1)
            if idB==1:
                resultadosB.loc[b, 'Valor']=valoresV[colB1][filaE] 
            else:
                resultadosB.loc[b, 'Valor']=(valoresV[colB1][filaE] + ' ' + 
                                         valoresV[colB2][filaE] + ' ' +
                                         valoresV[colB3][filaE] )
            if colND!='':
                resultadosB.loc[b, 'Valor']=resultadosB.loc[b, 'Valor']+';'+valoresV[colND][filaE] 
        else:
            # Concatenar y deduplicar valores
            fila_actual = str(filaE+row_offset)
            columna_actual = str(a+1)
            
            if idB==1:
                valor_actual = valoresV[colB1][filaE]
            else:
                valor_actual = (valoresV[colB1][filaE] + ' ' + 
                               valoresV[colB2][filaE] + ' ' +
                               valoresV[colB3][filaE])
            if colND!='':
                valor_actual = valor_actual + ';' + valoresV[colND][filaE]
            
            filas_list = resultadosB.loc[b, 'Fila'].split('|')
            columnas_list = resultadosB.loc[b, 'Columna'].split('|')
            valores_list = resultadosB.loc[b, 'Valor'].split('|')
            
            # Agregar solo si no existe duplicado
            if fila_actual not in filas_list:
                filas_list.append(fila_actual)
            if columna_actual not in columnas_list:
                columnas_list.append(columna_actual)
            if valor_actual not in valores_list:
                valores_list.append(valor_actual)
            
            resultadosB.loc[b, 'Libro']=resultadosB.loc[b, 'Libro'] + '|' + libro
            resultadosB.loc[b, 'Hoja']=resultadosB.loc[b, 'Hoja'] + '|' + libro
            resultadosB.loc[b, 'Fila']='|'.join(filas_list)
            resultadosB.loc[b, 'Columna']='|'.join(columnas_list)
            resultadosB.loc[b, 'Valor']='|'.join(valores_list) 
        if auxP>validar_porcentaje(resultadosB.loc[b, 'Porcentaje']):
            resultadosB.loc[b, 'Porcentaje']=str(auxP)
    else:
        print('LlenarResultados1_P_1_2_2' + '_'+str(fila))
        if auxP>validar_porcentaje(resultadosB.loc[b, 'Porcentaje']):
            resultadosB.loc[b, 'Porcentaje']=str(auxP)
            if resultadosB.loc[b, 'Libro']=="":
                resultadosB.loc[b, 'Libro']=libro#fbasetB[0]
                resultadosB.loc[b, 'Hoja']=libro
                resultadosB.loc[b, 'Fila']=str(valoresV.index[0]+row_offset) #str(a+1)
                resultadosB.loc[b, 'Columna']=str(a+1)
                resultadosB.loc[b, 'Valor']= valoresV[colB1][filaE]
            else:
                resultadosB.loc[b, 'Libro']=resultadosB.loc[b, 'Libro'] + '|' + libro
                resultadosB.loc[b, 'Hoja']=resultadosB.loc[b, 'Hoja'] + '|' + libro
                resultadosB.loc[b, 'Fila']=resultadosB.loc[b, 'Fila'] + '|' + str(valoresV.index[0]+row_offset)
                resultadosB.loc[b, 'Columna']=resultadosB.loc[b, 'Columna'] + '|' + str(a+1)
                resultadosB.loc[b, 'Valor']= resultadosB.loc[b, 'Valor'] + '|' + valoresV[colB1][filaE]
            if colND!='':
                resultadosB.loc[b, 'Valor']=resultadosB.loc[b, 'Valor']+';'+valoresV[colND][filaE] 
        else:
            pass
                    
#==============================================================================
#Leer Resultado
#Funcion que obtiene datos de la matriz de busqueda
#==============================================================================
def LeerResultados(narchivo, nhoja):
    rutaOrig=varInicial [1][0]
    excel_of=pd.ExcelFile(rutaOrig +'\\' + narchivo) #Lee archivo excel
    hojaB=excel_of.parse(nhoja,usecols =[0,1,2,3,4,5,6,7,8,9,10],dtype =str)#Solo leer las columnas que existen (0-10)
    hojaB.fillna("", inplace = True)
    excel_of.close()
    return hojaB
#==============================================================================
#==============================================================================
#Proceso que crea variable de Area Registral
#==============================================================================
def MenuP():
    global root
    root = tk.Tk()  #tkinter.Tk()  
    root.title('Menú Principal')
    root.geometry("1000x400")
    root.resizable(True, True)
    
    # Configurar pesos de filas y columnas para que se adapten
    root.grid_rowconfigure(0, weight=1)
    root.grid_rowconfigure(1, weight=1)
    root.grid_columnconfigure(0, weight=1)
    root.grid_columnconfigure(1, weight=1)
    
    # FILA 0 (Superior)
    #Opcion 1 - Limpiar Base de Datos (Naranja - Arriba a la izquierda)
    botonNuevo5 = tk.Button(root, text="Limpiar Base de Datos" +'\n' + 
                            "SQLite" +'\n' + "(Cajas)",
                            fg="white", bg="#FF8C00", font=("Arial", 11, "bold"),
                            command=Close_Window_5, padx=25, pady=25)
    botonNuevo5.grid(row=0, column=0, padx=5, sticky="nsew", pady=5)

    #Opcion 2 - BASE 1 (Verde - Arriba a la derecha)
    botonNuevo2 = tk.Button(root, text="Iniciar Busqueda en :" +'\n' + 
                            "1_BANCOS_VEND_INMUEB" +'\n' + "_CREDHIP_2025.xlsx",
                            fg="white", bg="#228B22", font=("Arial", 11, "bold"),
                            command=Close_Window_2, padx=25, pady=25)
    botonNuevo2.grid(row=0, column=1, padx=5, sticky="nsew", pady=5)
    
    # FILA 1 (Inferior)
    #Opcion 3 - Convertir Data (Rojo - Abajo a la izquierda, ocupa toda la altura)
    botonNuevo1 = tk.Button(root, text="Convertir Data " +'\n' + "de Busqueda",
                            fg="white", bg="#8B0000", font=("Arial", 12, "bold"),
                            command=Close_Window_1, padx=25, pady=25)
    botonNuevo1.grid(row=1, column=0, padx=5, sticky="nsew", pady=5)

    #Opcion 4 - BASE 2 (Azul Oscuro - Centro-derecha abajo)
    botonNuevo3 = tk.Button(root, text="Iniciar Busqueda en :" +'\n' + 
                            "2_CAJAS_" +'\n' + "CREDDESEMBOLSADOS_2025.txt",
                            fg="white", bg="#00008B", font=("Arial", 11, "bold"),
                            command=Close_Window_3, padx=25, pady=25)
    botonNuevo3.grid(row=1, column=1, padx=5, sticky="nsew", pady=5)
    
    #Opcion 5 - BASE 3 (Azul Claro - Derecha abajo)
    botonNuevo4 = tk.Button(root, text="Iniciar Busqueda en :" +'\n' + 
                            "3_TBL_MUNI_PREDIOS" +'\n' + "_2023.txt",
                            fg="black", bg="#87CEEB", font=("Arial", 11, "bold"),
                            command=Close_Window_4, padx=25, pady=25)
    botonNuevo4.grid(row=2, column=1, padx=5, sticky="nsew", pady=5)

    
    root.mainloop()

#==============================================================================
#==============================================================================
# NUEVA FUNCIÓN: Búsqueda en MUNICIPIOS/PREDIOS con salida en DOS HOJAS
#==============================================================================
def PBusquedaMuniPredios(carpeta_salida):
    """
    Realiza búsqueda en base de datos de MUNICIPIOS (3_TBL_MUNI_PREDIOS_2023).
    Genera salida en un archivo Excel con DOS HOJAS:
    - HOJA "REPORTE": Resumen con Porcentaje ("CON COINCIDENCIAS" / "SIN COINCIDENCIAS")
    - HOJA "DETALLE": Solo registros con coincidencia > 80%
    """
    try:
        print("\n" + "="*80)
        print("INICIANDO BÚSQUEDA EN MUNICIPIOS/PREDIOS")
        print("="*80)
        
        ruta_base = varInicial[1][0]
        
        # PASO 1: Leer Base de Búsqueda
        print("\nPASO 1: Cargando Base_Busqueda.xlsx...")
        try:
            resultadosB = LeerResultados('Base_Busqueda.xlsx', 'Base')
            print(f"   Cargadas {len(resultadosB)} búsquedas")
        except Exception as e:
            print(f"   Error: {e}")
            py.alert(f"Error al leer Base_Busqueda.xlsx:\n{e}")
            return
        
        # PASO 2: Leer Base de Datos MUNI PREDIOS
        print("\nPASO 2: Cargando 3_TBL_MUNI_PREDIOS_2023.txt...")
        try:
            basetB = leerBaseDatos('3_TBL_MUNI_PREDIOS_2023.txt')
            print(f"   Base de datos cargada: {basetB[0][1]}")
            print(f"   Total registros: {len(basetB[0][2])}")
        except Exception as e:
            print(f"   Error: {e}")
            py.alert(f"Error al leer Base de Datos:\n{e}")
            return
        
        # PASO 3: Preparar DataFrames de resultado
        print("\nPASO 3: Iniciando búsqueda...")
        df_resumen = resultadosB.copy()
        df_resumen['Porcentaje'] = "SIN COINCIDENCIAS"  # Por defecto sin coincidencias
        
        registros_detalle = []  # Recopilar registros encontrados
        
        # PASO 4: Búsqueda por cada nombre en Base_Busqueda
        for idx, fila in resultadosB.iterrows():
            nombre_busqueda = str(fila['NOMBRE_BUSQUEDA']).strip()
            
            if len(nombre_busqueda) == 0:
                print(f"  Fila {idx}: NOMBRE_BUSQUEDA vacío")
                continue
            
            # Para MUNI PREDIOS: mostrar RAZON_SOCIAL (que es lo que se busca realmente)
            razon_social_display = str(fila.get('RAZON_SOCIAL', '')).strip() if 'RAZON_SOCIAL' in fila.index else ""
            if razon_social_display:
                print(f"\n  [{idx}] Buscando (RAZON_SOCIAL): {razon_social_display}")
            else:
                print(f"\n  [{idx}] Buscando (NOMBRE_BUSQUEDA): {nombre_busqueda}")
            
            # Variables para búsqueda
            encontrado = False
            mejor_similitud = 0
            
            # CASO A: Búsqueda exacta por nro_doc
            nro_doc = str(fila.get('NRO_DOC', '')).strip() if 'NRO_DOC' in fila.index else ""
            if len(nro_doc) > 0:
                try:
                    resultado = basetB[0][2][basetB[0][2]['nro_doc'].astype(str).str.strip() == nro_doc]
                    if len(resultado) > 0:
                        print(f"       ENCONTRADO en nro_doc (100%)")
                        mejor_similitud = 100
                        encontrado = True
                        # Agregar al detalle
                        for fila_idx, fila_resultado in resultado.iterrows():
                            registro_detalle = fila_resultado.copy()
                            registro_detalle['nombrebusq'] = nombre_busqueda
                            registro_detalle['porcetbusq'] = 100
                            registros_detalle.append(registro_detalle)
                except Exception as e:
                    print(f"      ! Error en búsqueda exacta: {e}")
            
            # CASO B: Búsqueda por RUC si no encontró antes
            if not encontrado and len(nro_doc) > 0:
                try:
                    resultado = basetB[0][2][basetB[0][2]['RUC_INFORMADO'].astype(str).str.strip() == nro_doc]
                    if len(resultado) > 0:
                        print(f"       ENCONTRADO en RUC_INFORMADO (100%)")
                        mejor_similitud = 100
                        encontrado = True
                        for fila_idx, fila_resultado in resultado.iterrows():
                            registro_detalle = fila_resultado.copy()
                            registro_detalle['nombrebusq'] = nombre_busqueda
                            registro_detalle['porcetbusq'] = 100
                            registros_detalle.append(registro_detalle)
                except Exception as e:
                    print(f"      ! Error en búsqueda RUC: {e}")
            
            # CASO C: Búsqueda por similitud en nombre (USANDO RAZON_SOCIAL)
            # Para MUNI PREDIOS: Usar RAZON_SOCIAL directamente (ya contiene nombre completo)
            if not encontrado:
                try:
                    # OPTIMIZACIÓN MUNI PREDIOS: Usar RAZON_SOCIAL en lugar de parsear NOMBRE_BUSQUEDA
                    # RAZON_SOCIAL es la base primordial que contiene el nombre completo del registro
                    razon_social = str(fila.get('RAZON_SOCIAL', '')).strip() if 'RAZON_SOCIAL' in fila.index else ""
                    
                    # Para MUNI PREDIOS usamos RAZON_SOCIAL directamente (sin fallback a NOMBRE_BUSQUEDA)
                    nombre_a_buscar = razon_social
                    nombre_upper = nombre_a_buscar.upper()
                    
                    print(f"      Buscando por RAZON_SOCIAL: '{nombre_a_buscar}'")
                    
                    # SOLUCIÓN 1: Filtro CONTAINS previo (filtra de 100K a ~5K registros)
                    # Usar primer palabra de RAZON_SOCIAL para filtrar registros que LO CONTENGAN
                    palabras = nombre_a_buscar.split()
                    primer_palabra = palabras[0].strip() if palabras else ''
                    
                    if primer_palabra and len(primer_palabra) > 2:
                        # Filtrar por CONTAINS primero (rápido)
                        print(f"      Filtrando registros que contienen '{primer_palabra}'...")
                        filtro_contiene = basetB[0][2]['nombre'].str.contains(
                            primer_palabra,
                            case=False,
                            na=False,
                            regex=False
                        )
                        registros_a_procesar = basetB[0][2][filtro_contiene]
                        print(f"      Registros a procesar: {len(registros_a_procesar)} (de {len(basetB[0][2])} totales)")
                    else:
                        # Si palabra muy corta, procesar todos
                        registros_a_procesar = basetB[0][2]
                        print(f"      Procesando todos los registros ({len(registros_a_procesar)})")
                    
                    # Calcular similitud SOLO en registros filtrados
                    similitudes = []
                    
                    for fila_idx, fila_resultado in registros_a_procesar.iterrows():
                        nombre_fila = str(fila_resultado.get('nombre', '')).strip()
                        if nombre_fila:
                            # Comparar directamente RAZON_SOCIAL con nombre de MUNI PREDIOS
                            ratio = difflib.SequenceMatcher(None, nombre_upper, nombre_fila.upper()).ratio() * 100
                            similitudes.append({
                                'indice': fila_idx,
                                'nombre': nombre_fila,
                                'similitud': ratio,
                                'fila': fila_resultado
                            })
                    
                    # Filtrar por similitud >= 80%
                    coincidencias = [s for s in similitudes if s['similitud'] >= 80]
                    
                    if coincidencias:
                        # Ordenar por similitud descendente
                        coincidencias.sort(key=lambda x: x['similitud'], reverse=True)
                        mejor = coincidencias[0]
                        mejor_similitud = mejor['similitud']
                        print(f"       ENCONTRADO por similitud ({mejor_similitud:.1f}%)")
                        
                        # Agregar TODOS los registros con similitud >= 80%
                        for coincidencia in coincidencias:
                            registro_detalle = coincidencia['fila'].copy()
                            # Guardar RAZON_SOCIAL en nombrebusq para trazabilidad
                            registro_detalle['nombrebusq'] = razon_social
                            registro_detalle['porcetbusq'] = coincidencia['similitud']
                            registros_detalle.append(registro_detalle)
                        
                        encontrado = True
                    else:
                        print(f"       Sin coincidencias >= 80%")
                        
                except Exception as e:
                    print(f"      ! Error en búsqueda por similitud: {e}")
            
            # Actualizar Porcentaje en RESUMEN
            if encontrado and mejor_similitud >= 80:
                df_resumen.loc[idx, 'Porcentaje'] = "CON COINCIDENCIAS"
            else:
                df_resumen.loc[idx, 'Porcentaje'] = "SIN COINCIDENCIAS"
        
        # PASO 5: Crear DataFrame de DETALLE
        print("\nPASO 5: Creando hoja DETALLE...")
        if len(registros_detalle) > 0:
            df_detalle = pd.DataFrame(registros_detalle)
            
            # Reorganizar columnas: primero nombrebusq y porcetbusq, luego el resto
            cols = df_detalle.columns.tolist()
            cols.remove('nombrebusq')
            cols.remove('porcetbusq')
            cols_reordenadas = ['nombrebusq', 'porcetbusq'] + cols
            df_detalle = df_detalle[cols_reordenadas]
            
            print(f"   {len(df_detalle)} registros encontrados con similitud >= 80%")
        else:
            df_detalle = pd.DataFrame()
            print(f"  ! Sin registros para mostrar en DETALLE")
        
        # PASO 6: Guardar en archivo Excel
        print("\nPASO 6: Generando archivo Excel...")
        archivo_salida = os.path.join(carpeta_salida, "Base_Busqueda_R_MuniPredios_2023.xlsx")
        
        try:
            with pd.ExcelWriter(archivo_salida, engine='openpyxl') as writer:
                # Hoja REPORTE
                df_resumen.to_excel(writer, sheet_name='REPORTE', index=False)
                print(f"   Hoja REPORTE creada ({len(df_resumen)} filas)")
                
                # Hoja DETALLE (solo si hay registros)
                if len(df_detalle) > 0:
                    df_detalle.to_excel(writer, sheet_name='DETALLE', index=False)
                    print(f"   Hoja DETALLE creada ({len(df_detalle)} filas)")
            
            print(f"\n Archivo guardado: {archivo_salida}")
            print("="*80)
            
            # RESUMEN FINAL
            con_coincidencias = (df_resumen['Porcentaje'] == 'CON COINCIDENCIAS').sum()
            sin_coincidencias = (df_resumen['Porcentaje'] == 'SIN COINCIDENCIAS').sum()
            
            mensaje = f"Búsqueda completada\n\n"
            mensaje += f"Total búsquedas: {len(df_resumen)}\n"
            mensaje += f"Con coincidencias: {con_coincidencias}\n"
            mensaje += f"Sin coincidencias: {sin_coincidencias}\n\n"
            mensaje += f"Registros en DETALLE: {len(df_detalle)}\n"
            mensaje += f"(similitud >= 80%)\n\n"
            mensaje += f"Archivo: Base_Busqueda_R_MuniPredios_2023.xlsx"
            
            py.alert(mensaje)
            
        except Exception as e:
            print(f"   Error guardando archivo: {e}")
            py.alert(f"Error al guardar archivo Excel:\n{e}")
            
    except Exception as e:
        print(f" Error en PBusquedaMuniPredios: {e}")
        py.alert(f"Error en búsqueda de Municipios:\n{e}")

#==============================================================================
#==============================================================================
# NUEVA FUNCIÓN: Búsqueda en BANCOS con salida en DOS HOJAS
#==============================================================================
def PBusquedaBancos(carpeta_salida):
    """
    Realiza búsqueda en base de datos de BANCOS (1_BANCOS_VEND_INMUEB_CREDHIP_2025).
    Genera salida en un archivo Excel con DOS HOJAS:
    - HOJA "REPORTE": Resumen con Porcentaje ("CON COINCIDENCIAS" / "SIN COINCIDENCIAS")
    - HOJA "DETALLE": Solo registros con coincidencia > 80%
    """
    try:
        print("\n" + "="*80)
        print("INICIANDO BÚSQUEDA EN BANCOS")
        print("="*80)
        
        ruta_base = varInicial[1][0]
        
        # PASO 1: Leer Base de Búsqueda
        print("\nPASO 1: Cargando Base_Busqueda.xlsx...")
        try:
            resultadosB = LeerResultados('Base_Busqueda.xlsx', 'Base')
            print(f"   Cargadas {len(resultadosB)} búsquedas")
        except Exception as e:
            print(f"   Error: {e}")
            py.alert(f"Error al leer Base_Busqueda.xlsx:\n{e}")
            return
        
        # PASO 2: Leer Base de Datos BANCOS (primera fila es header, segunda contiene datos)
        print("\nPASO 2: Cargando 1_BANCOS_VEND_INMUEB_CREDHIP_2025.xlsx...")
        try:
            basetB = leerBaseDatos('1_BANCOS_VEND_INMUEB_CREDHIP_2025.xlsx', skiprows=1)
            print(f"   Base de datos cargada: {basetB[0][1]}")
            print(f"   Total registros: {len(basetB[0][2])}")
        except Exception as e:
            print(f"   Error: {e}")
            py.alert(f"Error al leer Base de Datos:\n{e}")
            return
        
        # PASO 3: Preparar DataFrames de resultado
        print("\nPASO 3: Iniciando búsqueda...")
        df_resumen = resultadosB.copy()
        df_resumen['Porcentaje'] = "SIN COINCIDENCIAS"  # Por defecto sin coincidencias
        
        registros_detalle = []  # Recopilar registros encontrados
        
        # PASO 4: Búsqueda por cada nombre en Base_Busqueda
        for idx, fila in resultadosB.iterrows():
            nombre_busqueda = str(fila['NOMBRE_BUSQUEDA']).strip()
            
            if len(nombre_busqueda) == 0:
                print(f"  Fila {idx}: NOMBRE_BUSQUEDA vacío")
                continue
            
            # Para BANCOS: mostrar RAZON_SOCIAL (que es lo que se busca realmente)
            razon_social_display = str(fila.get('RAZON_SOCIAL', '')).strip() if 'RAZON_SOCIAL' in fila.index else ""
            if razon_social_display:
                print(f"\n  [{idx}] Buscando (RAZON_SOCIAL): {razon_social_display}")
            else:
                print(f"\n  [{idx}] Buscando (NOMBRE_BUSQUEDA): {nombre_busqueda}")
            
            # Variables para búsqueda
            encontrado = False
            mejor_similitud = 0
            
            # CASO A: Búsqueda exacta por nro_doc
            nro_doc = str(fila.get('NRO_DOC', '')).strip() if 'NRO_DOC' in fila.index else ""
            if len(nro_doc) > 0:
                try:
                    resultado = basetB[0][2][basetB[0][2]['nro_doc'].astype(str).str.strip() == nro_doc]
                    if len(resultado) > 0:
                        print(f"       ENCONTRADO en nro_doc (100%)")
                        mejor_similitud = 100
                        encontrado = True
                        # Agregar al detalle
                        for fila_idx, fila_resultado in resultado.iterrows():
                            registro_detalle = fila_resultado.copy()
                            registro_detalle['nombrebusq'] = nombre_busqueda
                            registro_detalle['porcetbusq'] = 100
                            registros_detalle.append(registro_detalle)
                except Exception as e:
                    print(f"      ! Error en búsqueda exacta: {e}")
            
            # CASO B: Búsqueda por RUC_INFORMADO si no encontró antes
            if not encontrado and len(nro_doc) > 0:
                try:
                    resultado = basetB[0][2][basetB[0][2]['RUC_INFORMADO'].astype(str).str.strip() == nro_doc]
                    if len(resultado) > 0:
                        print(f"       ENCONTRADO en RUC_INFORMADO (100%)")
                        mejor_similitud = 100
                        encontrado = True
                        for fila_idx, fila_resultado in resultado.iterrows():
                            registro_detalle = fila_resultado.copy()
                            registro_detalle['nombrebusq'] = nombre_busqueda
                            registro_detalle['porcetbusq'] = 100
                            registros_detalle.append(registro_detalle)
                except Exception as e:
                    print(f"      ! Error en búsqueda RUC: {e}")
            
            # CASO C: Búsqueda por componentes de nombre (apellido paterno, materno, nombres)
            # Para BANCOS: Usar NOMBRE_BUSQUEDA parseado en componentes
            if not encontrado:
                try:
                    # BANCOS: Parsear NOMBRE_BUSQUEDA (formato: "APE_PAT|APE_MAT|NOMBRES")
                    componentes = nombre_busqueda.split('|')
                    
                    # Validar que tenemos al menos 3 elementos después del split
                    if len(componentes) < 3:
                        # Rellenar con cadenas vacías si faltan elementos
                        while len(componentes) < 3:
                            componentes.append('')
                    
                    ape_pat_busq = componentes[0].strip()
                    ape_mat_busq = componentes[1].strip()
                    nombres_busq = componentes[2].strip()
                    
                    print(f"      Buscando por componentes: APE_PAT='{ape_pat_busq}' | APE_MAT='{ape_mat_busq}' | NOMBRES='{nombres_busq}'")
                    
                    # Paso 1: Filtrar por apellido paterno (CONTAINS)
                    if ape_pat_busq and len(ape_pat_busq) > 2:
                        print(f"      Filtrando por APE_PAT (contiene '{ape_pat_busq}')...")
                        filtro_ape_pat = basetB[0][2]['ape_pat'].str.contains(
                            ape_pat_busq,
                            case=False,
                            na=False,
                            regex=False
                        )
                        registros_filtro1 = basetB[0][2][filtro_ape_pat]
                        print(f"      Registros después APE_PAT: {len(registros_filtro1)}")
                    else:
                        registros_filtro1 = basetB[0][2]
                        print(f"      APE_PAT vacío o muy corto, procesando todos ({len(registros_filtro1)})")
                    
                    # Paso 2: Filtrar adicionalmente por apellido materno
                    if ape_mat_busq and len(ape_mat_busq) > 2 and len(registros_filtro1) > 0:
                        print(f"      Filtrando por APE_MAT (contiene '{ape_mat_busq}')...")
                        filtro_ape_mat = registros_filtro1['ape_mat'].str.contains(
                            ape_mat_busq,
                            case=False,
                            na=False,
                            regex=False
                        )
                        registros_filtro2 = registros_filtro1[filtro_ape_mat]
                        print(f"      Registros después APE_MAT: {len(registros_filtro2)}")
                    else:
                        registros_filtro2 = registros_filtro1
                        print(f"      APE_MAT vacío o muy corto, usando filtro anterior ({len(registros_filtro2)})")
                    
                    # Paso 3: Buscar coincidencias exactas en registros filtrados
                    if len(registros_filtro2) > 0:
                        print(f"      Buscando coincidencias exactas/parciales en {len(registros_filtro2)} registros...")
                        
                        registros_encontrados = []  # Tracking temporal para esta búsqueda
                        
                        for fila_idx, fila_resultado in registros_filtro2.iterrows():
                            ape_pat_db = str(fila_resultado.get('ape_pat', '')).strip().upper()
                            ape_mat_db = str(fila_resultado.get('ape_mat', '')).strip().upper()
                            nombre_db = str(fila_resultado.get('nombre', '')).strip().upper()
                            
                            # Comparar componentes
                            ape_pat_match = ape_pat_db == ape_pat_busq.upper()
                            ape_mat_match = ape_mat_db == ape_mat_busq.upper()
                            nombre_match = nombre_db == nombres_busq.upper()
                            
                            # Calcular porcentaje de coincidencia
                            components_total = 3
                            components_coinciden = sum([ape_pat_match, ape_mat_match, nombre_match])
                            porcentaje = (components_coinciden / components_total) * 100
                            
                            # Aceptar coincidencias >= 60% (al menos 2 de 3 componentes)
                            if porcentaje >= 60:
                                registro_detalle = fila_resultado.copy()
                                registro_detalle['nombrebusq'] = nombre_busqueda
                                registro_detalle['porcetbusq'] = porcentaje
                                registros_encontrados.append(porcentaje)
                                registros_detalle.append(registro_detalle)
                                
                                if porcentaje == 100:
                                    mejor_similitud = 100
                                    encontrado = True
                                    print(f"       ENCONTRADO (100% - exacto)")
                                    break
                        
                        # Si encontró algo (aunque sea parcial >= 60%)
                        if len(registros_encontrados) > 0:
                            mejor_similitud = max(registros_encontrados)
                            encontrado = True
                            print(f"       ENCONTRADO por componentes ({mejor_similitud:.0f}%)")
                        else:
                            print(f"       Sin coincidencias >= 60%")
                    else:
                        print(f"       Sin registros después de filtros")
                        
                except Exception as e:
                    print(f"      ! Error en búsqueda por componentes: {e}")
            
            # Actualizar Porcentaje en RESUMEN
            if encontrado and mejor_similitud >= 80:
                df_resumen.loc[idx, 'Porcentaje'] = "CON COINCIDENCIAS"
            else:
                df_resumen.loc[idx, 'Porcentaje'] = "SIN COINCIDENCIAS"
        
        # PASO 5: Crear DataFrame de DETALLE
        print("\nPASO 5: Creando hoja DETALLE...")
        if len(registros_detalle) > 0:
            df_detalle = pd.DataFrame(registros_detalle)
            
            # Reorganizar columnas: primero nombrebusq y porcetbusq, luego el resto
            cols = df_detalle.columns.tolist()
            cols.remove('nombrebusq')
            cols.remove('porcetbusq')
            cols_reordenadas = ['nombrebusq', 'porcetbusq'] + cols
            df_detalle = df_detalle[cols_reordenadas]
            
            print(f"   {len(df_detalle)} registros encontrados con similitud >= 80%")
        else:
            df_detalle = pd.DataFrame()
            print(f"  ! Sin registros para mostrar en DETALLE")
        
        # PASO 6: Guardar en archivo Excel
        print("\nPASO 6: Generando archivo Excel...")
        archivo_salida = os.path.join(carpeta_salida, "Base_Busqueda_R_Bancos_VendInmuebles_2025.xlsx")
        
        try:
            with pd.ExcelWriter(archivo_salida, engine='openpyxl') as writer:
                # Hoja REPORTE
                df_resumen.to_excel(writer, sheet_name='REPORTE', index=False)
                print(f"   Hoja REPORTE creada ({len(df_resumen)} filas)")
                
                # Hoja DETALLE (solo si hay registros)
                if len(df_detalle) > 0:
                    df_detalle.to_excel(writer, sheet_name='DETALLE', index=False)
                    print(f"   Hoja DETALLE creada ({len(df_detalle)} filas)")
            
            print(f"\n Archivo guardado: {archivo_salida}")
            print("="*80)
            
            # RESUMEN FINAL
            con_coincidencias = (df_resumen['Porcentaje'] == 'CON COINCIDENCIAS').sum()
            sin_coincidencias = (df_resumen['Porcentaje'] == 'SIN COINCIDENCIAS').sum()
            
            mensaje = f"Búsqueda completada\n\n"
            mensaje += f"Total búsquedas: {len(df_resumen)}\n"
            mensaje += f"Con coincidencias: {con_coincidencias}\n"
            mensaje += f"Sin coincidencias: {sin_coincidencias}\n\n"
            mensaje += f"Registros en DETALLE: {len(df_detalle)}\n"
            mensaje += f"(similitud >= 80%)\n\n"
            mensaje += f"Archivo: Base_Busqueda_R_Bancos_VendInmuebles_2025.xlsx"
            
            py.alert(mensaje)
            
        except Exception as e:
            print(f"   Error guardando archivo: {e}")
            py.alert(f"Error al guardar archivo Excel:\n{e}")
            
    except Exception as e:
        print(f" Error en PBusquedaBancos: {e}")
        py.alert(f"Error en búsqueda de Bancos:\n{e}")

#==============================================================================
#Procesos de Menú:
#Opciones del Menu Principal
#==============================================================================
def Close_Window_1 ():
    root.destroy()
    procesoP1()
    print("Proceso Finalizo con exito ==> se completo la columna de Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_2 ():
    root.destroy()
    PBusquedaP(1)
    print("Proceso Finalizo con exito ==> se completo Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_3 ():
    root.destroy()
    PBusquedaP(2)
    print("Proceso Finalizo con exito ==> se completo Busqueda")
    py.alert("Proceso Ejecutado con exito ",timeout=1600)
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_4 ():
    root.destroy()
    carpeta_salida = crear_carpeta_resultados()
    PBusquedaMuniPredios(carpeta_salida)
    print("Proceso Finalizo con exito ==> se completo Busqueda en Municipios")
    MenuP()
#==============================================================================
#==============================================================================
def Close_Window_5 ():
    root.destroy()
    EliminarBaseDatos()
    MenuP()
#==============================================================================
#==============================================================================
# Procedimiento para ejecutar la funcion de completar columna de busuqeda
# 
#==============================================================================   
def procesoP1():
    #baseData=leerBaseDatos
    carpeta_salida = crear_carpeta_resultados()
    TP1.completar_NB1(1,varInicial[1][0],carpeta_salida)

        
#==============================================================================
#================================================================================
# Procedimiento para :
# 
#==============================================================================   
def busquedaPrincipal():
    #baseData=leerBaseDatos
    PBusquedaP()
        
#==============================================================================
#==============================================================================
# Funcion principal que llama a las diversas funciones para la ejecucion de los 
# procesos
#==============================================================================
def main():
     try:
         py.alert("Ejecutando ROBOT SSUNARP ",timeout=800)#Mensaje de incio de asignacion
         ParametrosInicio()
         MenuP()
         # busquedaPrincipal()
         print(varInicial)
         print("Finalizo con exito")
     except Exception as e:
         print("Se produjo un error")
         print(e)
         SystemExit()
         
if __name__ == "__main__":
    main()